-----------------------------------------------------------------------------
--  Licensed Materials - Property of IBM 
--  IBM Universal Behavioral Exchange Toolkit Materials
--  System Table DDLs for IBM Universal Behavioral Exchange Toolkit
--  (c) Copyright IBM Corporation 2015, 2016.
--  US Government Users Restricted Rights - Use, duplication or disclosure
--  restricted by GSA ADP Schedule Contract with IBM Corp. 
-----------------------------------------------------------------------------
CREATE TABLE UBX_SentSMS (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	EventCode		varchar(64),
	EventTimestamp	timestamp NOT NULL,
	EventNamespace	varchar(64),
	EventVersion	varchar(64),
	ContactId		varchar(64),
	MobileNumber	varchar(64),
	EventName		varchar(256),
	DeliveryStatus	varchar(64),
	ProgramType		varchar(64),
	LocationCountry	varchar(64),
	Code			varchar(64),
	MessageType		varchar(64),
	MailingTemplateId			varchar(256),
	ExternalSystemReferenceId	varchar(256),
	Source			varchar(256),
	ProgramId		varchar(64),
	CampaignName	varchar(256),
	ProgramName		varchar(256),
	MessageBody		varchar(256),
	EventId			varchar(64),	
	CONSTRAINT tUBX_SentSMS_PK PRIMARY KEY (RecordID)
);

CREATE TABLE UBX_InteractedSMS (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	EventCode		varchar(64),
	EventTimestamp	timestamp NOT NULL,
	EventNamespace	varchar(64),
	EventVersion	varchar(64),
	ContactId		varchar(64),
	MobileNumber	varchar(64),
	EventName		varchar(256),
	CampaignName	varchar(256),
	ProgramName		varchar(256),
	ProgramType		varchar(64),
	SetConsent		varchar(64),
	Source			varchar(256),
	EventId			varchar(64),
	CONSTRAINT tUBX_InteractedSMS_PK PRIMARY KEY (RecordID)
);

CREATE TABLE UBX_App_Installed  (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	EventCode		varchar(64),
	EventTimestamp	timestamp NOT NULL,
	EventNamespace	varchar(64),
	EventVersion	varchar(64),
	UserId			varchar(64),
	AppKey			varchar(64),
	ChannelId		varchar(64),
	Url				varchar(64),
	Attribution		varchar(64),
	CONSTRAINT tUBX_App_Installed_PK PRIMARY KEY (RecordID)
);
CREATE TABLE UBX_App_Uninstalled (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	EventCode		varchar(64),
	EventTimestamp	timestamp NOT NULL,
	EventNamespace	varchar(64),
	EventVersion	varchar(64),
	UserId			varchar(64),
	AppKey			varchar(64),
	ChannelId		varchar(64),
	Url				varchar(64),
	Attribution		varchar(64),
	CONSTRAINT tUBX_App_Uninstalled_PK PRIMARY KEY (RecordID)
);
CREATE TABLE UBX_App_SessionStarted (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	EventCode		varchar(64),
	EventTimestamp	timestamp NOT NULL,
	EventNamespace	varchar(64),
	EventVersion	varchar(64),
	UserId			varchar(64),
	AppKey			varchar(64),
	ChannelId		varchar(64),
	Url				varchar(64),
	Attribution		varchar(64),
	CONSTRAINT tUBX_App_SessionStarted_PK PRIMARY KEY (RecordID)
);
CREATE TABLE UBX_App_SessionEnded (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	EventCode		varchar(64),
	EventTimestamp	timestamp NOT NULL,
	EventNamespace	varchar(64),
	EventVersion	varchar(64),
	UserId			varchar(64),
	AppKey			varchar(64),
	ChannelId		varchar(64),
	Url				varchar(64),
	Attribution		varchar(64),
	CONSTRAINT tUBX_App_SessionEnded_PK PRIMARY KEY (RecordID)
);
CREATE TABLE UBX_App_UIPushEnabled (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	EventCode		varchar(64),
	EventTimestamp	timestamp NOT NULL,
	EventNamespace	varchar(64),
	EventVersion	varchar(64),
	UserId			varchar(64),
	AppKey			varchar(64),
	ChannelId		varchar(64),
	Url				varchar(64),
	Attribution		varchar(64),
	CONSTRAINT tUBX_App_UIPushEnabled_PK PRIMARY KEY (RecordID)
);
CREATE TABLE UBX_App_UIPushDisabled (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	EventCode		varchar(64),
	EventTimestamp	timestamp NOT NULL,
	EventNamespace	varchar(64),
	EventVersion	varchar(64),
	UserId			varchar(64),
	AppKey			varchar(64),
	ChannelId		varchar(64),
	Url				varchar(64),
	Attribution		varchar(64),
	CONSTRAINT tUBX_App_UIPushDisabled_PK PRIMARY KEY (RecordID)
);
CREATE TABLE UBX_SimpNot_AppOpened (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	EventCode		varchar(64),
	EventTimestamp	timestamp NOT NULL,
	EventNamespace	varchar(64),
	EventVersion	varchar(64),
	UserId			varchar(64),
	AppKey			varchar(64),
	ChannelId		varchar(64),
	Url				varchar(64),
	Attribution		varchar(64),
	CONSTRAINT tUBX_SimpNot_AppOpened_PK PRIMARY KEY (RecordID)
);

CREATE TABLE UBX_SimpNot_URLClicked (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	EventCode		varchar(64),
	EventTimestamp	timestamp NOT NULL,
	EventNamespace	varchar(64),
	EventVersion	varchar(64),
	UserId			varchar(64),
	AppKey			varchar(64),
	ChannelId		varchar(64),
	Url				varchar(64),
	Attribution		varchar(64),
	CONSTRAINT tUBX_SimpNot_URLClicked_PK PRIMARY KEY (RecordID)
);


CREATE TABLE UBX_WFX_EVENTS (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	EventCode		varchar(64),
	EventTimestamp	timestamp NOT NULL,
	EventNamespace	varchar(64),
	EventVersion	varchar(64),
	PostalCode		varchar(64),
	CountryCode		varchar(64),
	CurrentDay		float,
	ForecastDay0	float,
	ForecastDay1	float,
	ForecastDay2	float,
	ForecastDay3	float,
	ForecastDay4	float,
	ForecastDay5	float,
	ForecastDay6	float,
	ForecastDay7	float,
	ForecastDay8	float,
	CONSTRAINT tUBX_WFX_EVENTS_PK PRIMARY KEY (RecordID)
);
