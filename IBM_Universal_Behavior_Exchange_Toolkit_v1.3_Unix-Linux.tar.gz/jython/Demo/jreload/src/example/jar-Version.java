package example;

public class Version {

 private int ver;

 public Version(int ver) {
  this.ver = ver;
 }

 public String toString() {
   return "version "+ver;
 }


}
