-----------------------------------------------------------------------------
--  Licensed Materials - Property of IBM 
--  IBM Universal Behavioral Exchange Toolkit Materials
--  System Table DDLs for IBM Universal Behavioral Exchange Toolkit
--  (c) Copyright IBM Corporation 2015, 2016.
--  US Government Users Restricted Rights - Use, duplication or disclosure
--  restricted by GSA ADP Schedule Contract with IBM Corp. 
-----------------------------------------------------------------------------
CREATE TABLE UBX_EmailSend (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	ContactId		nvarchar(64) NULL,
	Email			nvarchar(64) NULL,
	EventCode		nvarchar(64) NOT NULL,
	EventTimeStamp	datetime NOT NULL,
	EventNameSpace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,			
	EventName		nvarchar(64) NULL,
	Description		nvarchar(128) NULL,
	MessageId		bigint NULL,
	MailingTemplateId bigint NULL,
	ReportId		nvarchar(64) NULL,	
	SubjectLine 	nvarchar(256) NULL,
	MessageName 	nvarchar(256) NULL,
	DocType	    	nvarchar(64) NULL,
	SendType    	nvarchar(64) NULL,
	EventId     	nvarchar(64) NULL,
    CONSTRAINT tUBX_EmailSend_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_EmailOpen (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	ContactId		nvarchar(64) NULL,
	Email			nvarchar(64) NULL,
	EventCode		nvarchar(64) NOT NULL,
	EventTimeStamp	datetime NOT NULL,
	EventNameSpace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,				
	EventName		nvarchar(64) NULL,
	Description		nvarchar(128) NULL,
	MessageId		bigint NULL,
	MailingTemplateId bigint NULL,
	ReportId		nvarchar(64) NULL,	
	SubjectLine 	nvarchar(256) NULL,
	MessageName 	nvarchar(256) NULL,
	DocType	    	nvarchar(64) NULL,
	EventId     	nvarchar(64) NULL,
    CONSTRAINT tUBX_EmailOpen_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_EmailClick (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	ContactId		nvarchar(64) NULL,
	Email			nvarchar(64) NULL,
	EventCode		nvarchar(64) NOT NULL,
	EventTimeStamp	datetime NOT NULL,
	EventNameSpace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,				
	EventName		nvarchar(64) NULL,
	Description		nvarchar(128) NULL,
	MessageId		bigint NULL,
	MailingTemplateId bigint NULL,
	ReportId		nvarchar(64) NULL,	
	SubjectLine 	nvarchar(256) NULL,
	MessageName 	nvarchar(256) NULL,
	DocType	    	nvarchar(64) NULL,
	ClickUrl    	nvarchar(128) NULL,
	UrlDescription  nvarchar(128) NULL,
	EventId     	nvarchar(64) NULL,
    CONSTRAINT tUBX_EmailClick_PK PRIMARY KEY (RecordID ASC)
);

CREATE TABLE UBX_EmailBounce (
	RecordID		bigint IDENTITY(1,1),
	Provider		nvarchar(64) NULL,
	EndpointSource	nvarchar(64) NULL,
	Channel			nvarchar(64) NULL,
	X1ID			nvarchar(64) NULL,
	ContactId		nvarchar(64) NULL,
	Email			nvarchar(64) NULL,
	EventCode		nvarchar(64) NOT NULL,
	EventTimeStamp	datetime NOT NULL,
	EventNameSpace	nvarchar(64) NULL,
	EventVersion	nvarchar(64) NULL,							
	EventName		nvarchar(64) NULL,	
	Description		nvarchar(128) NULL,
	MessageId		bigint NULL,
	MailingTemplateId bigint NULL,
	ReportId		nvarchar(64) NULL,	
	SubjectLine 	nvarchar(256) NULL,
	MessageName 	nvarchar(256) NULL,
	DocType	    	nvarchar(64) NULL,
	BounceType    	nvarchar(64) NULL,
	EventId     	nvarchar(64) NULL,
    CONSTRAINT tUBX_EmailBounce_PK PRIMARY KEY (RecordID ASC)
);
