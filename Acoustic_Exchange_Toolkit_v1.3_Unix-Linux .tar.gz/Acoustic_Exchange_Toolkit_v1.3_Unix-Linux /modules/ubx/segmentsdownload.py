##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015, 2016.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import os
import sys
import getopt
import time

from conf.cfg import getAbsolutePath
from conf.ubxconfig import UBXConfig
from ubx.apimanager import UBXAPIManager
from ubx.segments import *
from ubx.jobs import *

from com.ibm.emm.integration.log import CSLogger
from java.lang import Exception

def DownloadSegments(argv):    

    # Parsing command line arguments                
    configPropsFileName = None
       
    usage = 'Usage: downloadSegments [-c <config properties file>]'    
    try:
        opts, args = getopt.getopt(argv,"hc:",["config="])
    except getopt.GetoptError:
        print usage
        sys.exit(64)
    for opt, arg in opts:        
        if opt in ("-c", "--config"):
            configPropsFileName = getAbsolutePath(arg)
    
    try:       
        # Initializing, loading configuration, etc.
        csLogger = CSLogger.setScript("downloadSegments")
        csLogger = CSLogger.getCSLogger("scripts.downloadSegments")        
        csLogger.info("***** Download Audiences script started. *****")  
        
        config = UBXConfig(configPropsFileName)
        authkey = config.getSegmentConsumerAuthenticationKey()
        
        apimanager = UBXAPIManager(config)
        
        # Get list of jobs ready for download
        jobs = apimanager.getJobs(authkey, JobCategory.SEGMENT_EXPORT, config.getSegmentConsumerEndpointID(), JobStatus.READY_FOR_DOWNLOAD)
        if (jobs is not None):  
            csLogger.info("Number of audiences to be downloaded: " + str(len(jobs)))
            
        i = 1
        if (jobs is not None):        
            for job in jobs:
                csLogger.info("Downloading audience " + str(i) + ": " + job.destinationSegmentName)                
                if (len(job.segmentDataFiles) > 0):
                    try:
                        csLogger.info("Number of files for audience: " + str(len(job.segmentDataFiles)))
                        apimanager.downloadSegmentData(job)
                        apimanager.setJobStatus(config.getSegmentConsumerAuthenticationKey(), job.jobId, JobStatus.COMPLETE)         
                    except IOError, ioe:
                        csLogger.error(str(ioe))       
                    except Exception, e:
                        csLogger.error(str(e))
                else:
                    csLogger.error("No audience files found for: " + job.destinationSegmentName)
                i = i + 1
    except Exception, e:
        csLogger.error("Download Audiences script terminating with error! " , e)                                         
            
    finally:
        csLogger.info("***** Download Audiences script completed. *****")  

if __name__ == '__main__':    
    DownloadSegments(sys.argv[1:])
