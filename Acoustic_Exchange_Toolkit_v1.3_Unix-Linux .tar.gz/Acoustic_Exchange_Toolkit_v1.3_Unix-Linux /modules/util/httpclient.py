##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015, 2016.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import sys.argv
import urllib
import os
from urllib2 import Request, urlopen, build_opener, install_opener, ProxyHandler
from httplib import HTTPConnection

from com.ibm.emm.integration.log import CSLogger
from conf.cfg import Config
from urlparse import urlparse
from java.net import Authenticator
from java.net import PasswordAuthentication
from java.net import Proxy
from java.net import InetSocketAddress
from java.lang import String
from java.lang import Integer
from java.net import URL
from java.net import HttpURLConnection
from java.io import InputStreamReader
from java.io import BufferedReader
from java.lang import StringBuffer
from java.lang import Exception
from java.lang import Boolean
from java.io import DataOutputStream

class HTTPPasswordAuthenticator(Authenticator):
    def __init__(self, config):
        self.config = config;
        self.proxyUsername = config.getProxyUserName()
        self.proxyPassword = config.getProxyPassword()
        
    def getPasswordAuthentication(self):
        return PasswordAuthentication(self.proxyUsername, list(self.proxyPassword));

class Response(object):
    def __init__(self):
        self.code = None
        self.data = None
    
    def read(self):
        return self.data
    
class HTTPClient(object):
    csLogger = CSLogger.getCSLogger("scripts.util.HTTPClient")
    
    def __init__(self, config):
        self.url = None
        self.opener = None
        self.config = config
        self.proxyUrl = config.getProxyUrl()
        self.proxyUsername = config.getProxyUserName()
        self.proxyPassword = config.getProxyPassword()

    def post(self, url, values, headers):
        data = urllib.urlencode(values)
        req = Request(url, data, headers)
        
        proxyObj = self.config.getProxyServer(url)
        if (proxyObj == None):
            self.csLogger.debug("No proxy defined")
            response = urlopen(req)
            the_page = response.read()
        else:
            self.csLogger.debug("proxy is enabled with or without creds")
            parsedUrl = urlparse(proxyObj.url)
            urlPart = parsedUrl.netloc.split(":")[0]
            proxyPort = parsedUrl.port
            self.csLogger.debug("proxyUrl:" + urlPart)
            self.csLogger.debug("proxyPort:" + str(proxyPort))
            try:
                if (proxyObj.noCreds == False):
                    self.csLogger.debug("proxy with credentials")
                    authenticator = HTTPPasswordAuthenticator(self.config)
                    Authenticator.setDefault(authenticator)
                    self.csLogger.debug("proxyObj noCreds: False")
                proxyServerObj = Proxy(Proxy.Type.HTTP, InetSocketAddress(String(urlPart) , Integer(proxyPort)))
                connection = URL(String(url)).openConnection(proxyServerObj)
                connection.setDoInput(Boolean(True))
                connection.setDoOutput(Boolean(True))
                connection.setUseCaches(Boolean(False))
                    
                for key in headers:
                    connection.setRequestProperty(String(key), String(headers[key]))
                    self.csLogger.debug("setting req property" + key + ':' + headers[key])
                dos = DataOutputStream(connection.getOutputStream())
                for key in values:
                    postParam = key + '=' + values[key]
                    self.csLogger.debug("postParam:" + postParam)
                    dos.writeBytes(String(postParam))
                    dos.flush()
                    dos.close()
                    
                if (connection.getResponseCode() == 407):
                    proxyAuthError = 'Proxy server is not authenticated. Please verify if config.properties has correct proxy settings (url, username, password)'
                    self.csLogger.error(proxyAuthError)
                    raise Exception(proxyAuthError)
                       
                inputStream = connection.getInputStream()
                inStream = BufferedReader(InputStreamReader(inputStream))
                sb = StringBuffer()
                inputData = inStream.readLine()
                while(inputData != None):
                    sb.append(inputData)
                    sb.append(os.linesep)
                    inputData = inStream.readLine()
            except Exception, e:
                raise e
            self.csLogger.debug("response(through proxy):" + sb.toString())
            the_page = sb

        return the_page
   
    def useProxy(self, url):
        proxyObj = self.config.getProxyServer(url)
        if (proxyObj is not None):
            return True
        return False
    
    def sendProxiedRestRequest(self, method, url, data, headers, handler):
        proxyObj = self.config.getProxyServer(url)
        if (proxyObj == None):
            self.csLogger.debug("No proxy defined")            
            return self.sendRestRequest(self, url, data, headers, handler)        
        else:
            self.csLogger.debug("proxy is enabled with or without creds")
            parsedUrl = urlparse(proxyObj.url)
            urlPart = parsedUrl.netloc.split(":")[0]
            proxyPort = parsedUrl.port
            self.csLogger.debug("proxyUrl:" + urlPart)
            self.csLogger.debug("proxyPort:" + str(proxyPort))
            response = Response()
            try:
                if (proxyObj.noCreds == False):
                    self.csLogger.debug("proxy with credentials")
                    authenticator = HTTPPasswordAuthenticator(self.config)
                    Authenticator.setDefault(authenticator)
                    self.csLogger.debug("proxyObj noCreds: False")
                proxyServerObj = Proxy(Proxy.Type.HTTP, InetSocketAddress(String(urlPart) , Integer(proxyPort)))
                connection = URL(String(url)).openConnection(proxyServerObj)
                connection.setDoInput(Boolean(True))
                if (data is not None):
                    connection.setDoOutput(Boolean(True))
                else:
                    connection.setDoOutput(Boolean(False))
                connection.setUseCaches(Boolean(False))
                
                if (isinstance(connection, HttpURLConnection)):
                    connection.setRequestMethod(method)

                for key in headers:
                    connection.setRequestProperty(String(key), String(headers[key]))
                    self.csLogger.debug("setting req property" + key + ':' + headers[key])
                    
                if (data is not None):
                    self.csLogger.debug("data:" + data)
                    dos = DataOutputStream(connection.getOutputStream())
                    dos.writeBytes(String(data))
                    dos.flush()
                    dos.close()
                    
                response.code = connection.getResponseCode()    
                if (connection.getResponseCode() == 407):
                    proxyAuthError = 'Proxy server is not authenticated. Please verify if config.properties has correct proxy settings (url, username, password)'
                    self.csLogger.error(proxyAuthError)                    
                    raise Exception(proxyAuthError)
                       
                inputStream = connection.getInputStream()
                inStream = BufferedReader(InputStreamReader(inputStream))
                sb = StringBuffer()
                inputData = inStream.readLine()
                while(inputData != None):
                    sb.append(inputData)
                    sb.append(os.linesep)
                    inputData = inStream.readLine()
            except Exception, e:
                response.code = connection.getResponseCode()    
                if (connection.getResponseCode() == 407):
                    proxyAuthError = 'Proxy server is not authenticated. Please verify if config.properties has correct proxy settings (url, username, password)'
                    self.csLogger.error(proxyAuthError)                    
                    raise Exception(proxyAuthError)
                raise e
            self.csLogger.debug("response(through proxy):" + sb.toString())
            response.data = sb.toString()

        return response

    def sendRequest(self, req, handler):
        if (handler is None):                                        
            response = urlopen(req)
        else:
            if (self.opener is None):
                self.opener = build_opener(handler)                
            response = self.opener.open(req)                
        return response

    def sendRestRequest(self, url, data, headers, handler):
        if (self.useProxy(url)):
            if (data is None):
                return self.sendProxiedRestRequest("GET", url, data, headers, handler)
            else:
                return self.sendProxiedRestRequest("POST", url, data, headers, handler)
        else:            
            req = Request(url, data, headers)
            return self.sendRequest(req, handler)

    def sendDeleteRequest(self, url, data, headers, handler):
        if (self.useProxy(url)):
            return self.sendProxiedRestRequest("DELETE", url, data, headers, handler)
        else:
            req = DeleteRequest(url, data, headers)
            return self.sendRequest(req, handler)
    
    def sendPutRequest(self, url, data, headers, handler):
        if (self.useProxy(url)):
            return self.sendProxiedRestRequest("PUT", url, data, headers, handler)
        else:
            req = PutRequest(url, data, headers)
            return self.sendRequest(req, handler)
    
    def getHttpConnection(self, host, port):
        return HTTPConnection(host, port, None)
            
class PutRequest(Request):
    def __init__(self, url, data, headers):
        self._method = "PUT"
        Request.__init__(self, url, data, headers)

    def get_method(self):
        return self._method
        
class DeleteRequest(Request):
    def __init__(self, url, data, headers):
        self._method = "DELETE"
        Request.__init__(self, url, data, headers)

    def get_method(self):
        return self._method
