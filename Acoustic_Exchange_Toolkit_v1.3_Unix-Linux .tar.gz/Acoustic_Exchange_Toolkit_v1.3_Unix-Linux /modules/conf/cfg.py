##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015, 2016.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import ConfigParser
import StringIO
import os
import os.path

from java.lang import IllegalArgumentException
from java.io import File
from java.lang import String

from com.ibm.emm.integration.util import NormalizeUtils
from com.ibm.emm.integration.config import ConfigReader
from com.ibm.emm.integration.log import CSLogger

def getEnv(name):
    try:
        return os.environ[name];
    except Exception:
        raise Exception, name + " environment variable is not set..."

def getCUHome():
    return getEnv("CU_HOME")

def getConfDir():
    return getCUHome() + os.sep + "conf"

def getAppDataDir():
    appdatadir = getCUHome() + os.sep + "AppData"
    if not os.path.exists(appdatadir):
        os.makedirs(appdatadir) 
    return appdatadir

def getAbsolutePath(path):
    if (os.path.isabs(path)):
        return path
    return getCUHome() + os.sep + path    

class ProxyServerObject: 
    def __init__(self):
        self.url = None
        self.noCreds = None
        self.username = None
        self.password = None
        
class Config(object):
    
    DEFAULT_CONFIG_FILE = "config.properties"
    DEFAULT_JDBC_FILE = "jdbc.properties"
    ROOT_SECTION = "ROOTSECTION"
    
    PROPERTIES_ENCODING = "encoding"
    
    # Proxy server properties
    PROPERTIES_PROXY_URL = "proxy.url"
    PROPERTIES_PROXY_USERNAME = "proxy.username"
    PROPERTIES_PROXY_PASSWORD = "proxy.password"
        
    configFilePath = None
    config = None
    
    csLogger = CSLogger.getCSLogger("scripts.config.Config")

    def __init__(self, cfgPath):
        # Constructor        
        configfiles = [getConfDir() + os.sep + self.DEFAULT_CONFIG_FILE]
        if (cfgPath is not None):
            self.configFilePath = cfgPath
            configfiles.append(cfgPath)
                                   
        self._loadAsProperties(configfiles)                        
        
    def _loadAsProperties(self, configfiles):        
        self.config = ConfigParser.RawConfigParser(None)        
        self.config.add_section(self.ROOT_SECTION)
        for cfgPath in configfiles:
            if( not (File(cfgPath)).exists() ):
                raise IllegalArgumentException('Configuration file does not exist: ' + cfgPath);
            self._loadAsEncryptedProperties(cfgPath)        
    
    def _loadAsEncryptedProperties(self, configFilePath):
        encryptedConfigFile= File(configFilePath);
        if( not encryptedConfigFile.exists() ):
            raise IllegalArgumentException('Configuration file does not exist: '+ configFilePath)              
        cr = ConfigReader(encryptedConfigFile)
        for propName in cr.getAvailableProperties():
            self.config.set(self.ROOT_SECTION, propName, cr.getStringProperty(propName, None, False));

    def getConfFilePath(self):
        return self.configFilePath
        
    def getRequiredProperty(self, propertyName):
        ret = self.getProperty(propertyName)
        if(ret.__len__()== 0):            
            raise IllegalArgumentException(propertyName+ " property has an empty value in the config file")
        return ret 
        
    def getOptionalProperty(self, propertyName):
        try:
            ret= self.config.get(Config.ROOT_SECTION, propertyName)
            if ret is not None:
                ret= ret.strip()
            return ret
        except ConfigParser.NoOptionError:
            return None
        
    def getIntProperty(self, propertyName):
        ret = self.getProperty(propertyName)
        try:
            return int(ret)        
        except ValueError:             
            raise IllegalArgumentException("The value provided for '"+ propertyName+ "' property ("+ str(ret)+ ") is not an integer in the config file")                

    def getBoolProperty(self, propertyName):
        ret = self.getProperty(propertyName)
        ret = ret.lower()
        if (ret == "false" or ret == "no"):
            return False
        return True
        
    def getProperty(self, propertyName):
        return self.get(propertyName)

    def get(self, propertyName):
        try:
            # use ROOT_SECTION instead of the sectionName
            return self.config.get(self.ROOT_SECTION, propertyName)
        except ConfigParser.NoOptionError:             
            raise IllegalArgumentException(propertyName+ " property is missing in the config file")                
        
    def getEncoding(self):
        return self.getOptionalProperty(self.PROPERTIES_ENCODING)    

    def getProxyUrl(self):
        return self.getOptionalProperty(self.PROPERTIES_PROXY_URL)
    
    def getProxyUserName(self):
        return self.getOptionalProperty(self.PROPERTIES_PROXY_USERNAME)
    
    def getProxyPassword(self):
        return self.getOptionalProperty(self.PROPERTIES_PROXY_PASSWORD)

    def getProxyServer(self, url):
        if (not self.isUrlConfigured(url)):
            return None
        proxyUrlStringVal = self.getProxyUrl()
        proxyUsernameStringVal = self.getProxyUserName()
        proxyPasswordStringVal = self.getProxyPassword()
        proxyObj = None
        if( (proxyUrlStringVal is None) or (len(proxyUrlStringVal) == 0)
            ): 
            return proxyObj 
        elif( ((proxyUsernameStringVal is None) or (len(proxyUsernameStringVal) == 0))
              and ((proxyPasswordStringVal is None) or (len(proxyPasswordStringVal) == 0))
            ):
            proxyObj = ProxyServerObject()
            proxyObj.url = proxyUrlStringVal
            proxyObj.noCreds = True
            return proxyObj
        else:
            proxyObj = ProxyServerObject()
            proxyObj.url = proxyUrlStringVal
            proxyObj.noCreds = False
            proxyObj.username = proxyUsernameStringVal
            proxyObj.password = proxyPasswordStringVal
            return proxyObj
        
    def isUrlConfigured(self, parmUrl):
        return True
