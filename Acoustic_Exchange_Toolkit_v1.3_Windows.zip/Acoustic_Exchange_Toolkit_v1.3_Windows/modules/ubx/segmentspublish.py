##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015, 2016.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import os
import sys
import getopt
import time
import csv

from conf.cfg import getAbsolutePath
from conf.ubxconfig import UBXConfig
from ubx.apimanager import UBXAPIManager
from ubx.segments import *

from com.ibm.emm.integration.log import CSLogger
from java.lang import Exception

def PublishSegments(argv):    

    # Parsing command line arguments                
    configPropsFileName = None
       
    usage = 'Usage: publishSegments [-c <config properties file>]'    
    try:
        opts, args = getopt.getopt(argv,"hc:",["config="])
    except getopt.GetoptError:
        print usage
        sys.exit(64)
    for opt, arg in opts:        
        if opt in ("-c", "--config"):
            configPropsFileName = getAbsolutePath(arg)
    
    try:       
        # Initializing, loading configuration, etc.
        csLogger = CSLogger.setScript("publishSegments")
        csLogger = CSLogger.getCSLogger("scripts.publishSegments")        
        config = UBXConfig(configPropsFileName)
        authkey = config.getSegmentProducerAuthenticationKey()
        
        apimanager = UBXAPIManager(config)
        
        hasSegmentsToPublish = False
        segmentPublishDir = config.getSegmentPublishFolder()

        # Get list of current published segments
        currentSegments = apimanager.getSegments(authkey)
        
        segmentFilesPublished = []      
        segmentFiles = os.listdir(segmentPublishDir)
        
        newSegments = []
        existingSegments = []
        
        for segmentFile in segmentFiles:
            segmentFilepath = segmentPublishDir + os.sep + segmentFile
            if os.path.isfile(segmentFilepath): 
                if segmentFile.startswith("UBXSegment_") and segmentFile.endswith(".csv"):                    
                    hasSegmentsToPublish = True
                    
                    filename = os.path.splitext(segmentFile)[0]
                    tokens = filename.split('_')
                    if (len(tokens) != 2):
                        csLogger.info("Skipping file: " + segmentFile)
                    else:
                        segmentName = tokens[1]
                        csLogger.info("Publish Segment: " + segmentName)
                                            
                        segment = findSegmentByName(currentSegments, segmentName)
                        if segment is None:
                            segmentId = int(round(time.time() * 1000))                     
                            segment = Segment(segmentId, segmentName, None)     
                            newSegments.append(segment)
                        else:
                            existingSegments.append(segment)
                                                       
                        # segment attributes
                        try:  
                            f =  open(segmentFilepath, 'rU')              
                            csvReader = csv.reader(f, delimiter=',')                
                            
                            # Read the first line as headers
                            colHeaders = csvReader.next()
                            csLogger.info("Column headers from file: " + ','.join(colHeaders))
                            for header in colHeaders:
                                segment.addSegmentAttribute(header, "Text")
                        finally:
                            f.close()
                        
                        csLogger.debug("Segment JSON=" + str(segment.toJSON()))   
    
                        segmentFilesPublished.append(segmentFile)
                else:
                    csLogger.info("Skipping file: " + segmentFile)
    
        if (len(newSegments) == 0 and len(existingSegments) == 0):
            csLogger.info("No segments to be published")
        
        if (len(newSegments) > 0):
            csLogger.info("Publishing " + str(len(newSegments)) + " new segments...")
            apimanager.addSegments(newSegments)

        if (len(existingSegments) > 0):
            csLogger.info("Republishing " + str(len(existingSegments)) + " segments...")
            for segment in existingSegments:
                apimanager.deleteSegment(segment.id)            
            apimanager.addSegments(existingSegments)
       
        # move csv files to published folder
        publishedDir = config.getSegmentPublishedFolder()
        for segmentFile in segmentFilesPublished:
            segmentFilepath = segmentPublishDir + os.sep + segmentFile
            destfile = publishedDir + os.sep + segmentFile                                            
            try:
                if (os.path.exists(destfile)):
                    os.remove(destfile)
                os.rename(segmentFilepath, destfile)
            except OSError:
                csLogger.error("Error moving file from " + segmentFilepath + " to " + destfile)                                   
    except Exception, e:        
        csLogger.error('Register Audiences script terminating with error!')
        csLogger.error(str(e.getMessage()),e)                                         
    finally:
        csLogger.info('Register Audiences script completed.')  

if __name__ == '__main__':    
    PublishSegments(sys.argv[1:])
