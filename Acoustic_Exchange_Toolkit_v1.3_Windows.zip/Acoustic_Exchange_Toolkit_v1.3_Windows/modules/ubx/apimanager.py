##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015, 2016.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
from com.ibm.emm.integration.log import CSLogger

import os
import re
import shutil
import time
from urllib import pathname2url
from urllib2 import URLError, HTTPErrorProcessor, HTTPError
from util.httpclient import HTTPClient
import simplejson as json
from ubx.jobs import *
from ubx.segments import *
from ubx.endpoints import *
from java.lang import Exception
from com.ibm.emm.integration.util import NormalizeUtils

class UBXAPIManager(object):    
    def __init__(self, config):
        self.csLogger = CSLogger.getCSLogger("ubx.UBXAPIManager") 
        self.config = config
        
    def handleHttpErrorCode(self, responseCode, responseData):
        msg = responseData        
        if (responseCode == 403):
            if (msg is None or len(msg) == 0):
                msg = "Not Authorized"
 
        self.csLogger.error("HTTP Response Code=" + str(responseCode) + ", msg=" + msg)
    
    def handleURLErrorException(self, e):
        self.csLogger.error(str(e))
    
    ##################################################################################
    # Service URLs
    ##################################################################################       
    def getAPIServiceURL(self):
        url = self.config.getAPIServiceURL()
        if (not url.endswith('/')):
            url = url + "/"
        return url

    def getEventFilesServiceURL(self):
        return self.getAPIServiceURL() + "v1/eventfiles/" 

    def getEndpointServiceURL(self):
        return self.getAPIServiceURL() + "v1/endpoint/" 
    
    def getApplicationEndpointServiceURL(self,externalAppId):
        return self.getAPIServiceURL() + "v1/endpoint/" + externalAppId + "/default"

    def getJobsServiceURL(self):
        return self.getAPIServiceURL() + "v1/jobs/" 
                                
    ##################################################################################
    # Events
    ##################################################################################                   
    def getEventFileList(self):
        httpClient = HTTPClient(self.config);
        url = self.getEventFilesServiceURL()
        
        if (url.endswith('/')):
            url = url[:-1]
        url = url + "?numFiles=" + str(self.config.getEventFilesNumFilesInList())
        headers = {'Authorization': 'Bearer ' + self.config.getEventConsumerAuthenticationKey() }
        
        try:
            handler = UBXHTTPErrorProcessor()
            response = httpClient.sendRestRequest(url, None, headers, handler)
        except URLError, e:
            self.handleURLErrorException(e)
            response = None
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code == 200):
                eventFiles = []
                if (responseData != ""):
                    getEventFileListResponse = GetEventFileListResponse(response.code, responseData)
                    fileList = getEventFileListResponse.getFileList()                    
                    if ( fileList is not None):
                        for f in fileList:                            
                            self.csLogger.info("id: " + f)        
                            eventFile = EventFile(f)
                            eventFiles.append(eventFile)
                    else:
                        self.csLogger.info("No files returned")
                    
                    return eventFiles        
            else:
                self.handleHttpErrorCode(response.code, responseData)                
        
        return None
                
    def getEventFile(self, eventFileId):
        httpClient = HTTPClient(self.config);
        headers = {'Authorization': 'Bearer ' + self.config.getEventConsumerAuthenticationKey() }
        url = self.getEventFilesServiceURL()
        url = url + pathname2url(eventFileId)
        self.csLogger.debug("HTTP Request=" + url)
        
        try:
            response = httpClient.sendRestRequest(url, None, headers, None)
        except URLError, e:
            self.handleURLErrorException(e)
            response = None
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code == 200):
                if (responseData != ""):
                    getEventFileResponse = GetEventFileResponse(response.code, responseData)
                    return getEventFileResponse.getFileContent()
            else:
                self.handleHttpErrorCode(response.code, responseData)
        
        return None
    
    def deleteEventFile(self, eventFileId):
        httpClient = HTTPClient(self.config);
        headers = {'Authorization': 'Bearer ' + self.config.getEventConsumerAuthenticationKey() }
        url = self.getEventFilesServiceURL()
        url = url + pathname2url(eventFileId)
        self.csLogger.debug("HTTP Request=" + url)
        
        try:
            response = httpClient.sendDeleteRequest(url, None, headers, None)
        except URLError, e:
            self.handleURLErrorException(e)
            response = None
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code == 200):
                return None
            else:
                self.handleHttpErrorCode(response.code, responseData)
                    
        return None
                   
    ##################################################################################
    # Endpoint registration
    ##################################################################################       
    def registerEndpoint(self, endpoint, authkey,externalAppId = None):
        httpClient = HTTPClient(self.config)
        headers = {'Authorization': 'Bearer ' + authkey,
                   'Content-Type': 'application/json',
                   'Accept-Charset': 'UTF-8'}
        data = json.dumps(endpoint)
        self.csLogger.debug("externalAppId=" + externalAppId)                
        url = self.getApplicationEndpointServiceURL(externalAppId)            
        self.csLogger.debug("HTTP Request=" + url)
        self.csLogger.debug("JSON=" + str(data))
        try:            
            response = httpClient.sendPutRequest(url, data, headers, None)
        except HTTPError, he:
            self.csLogger.error("HTTPError while registering Endpoint : " + str(he) + ", msg: " + he.read())
            response = None
        except URLError, ue:
            self.csLogger.error("URLError while registering Endpoint : " + str(ue) )
            response = None
        except Exception, je:
            self.csLogger.error("Exception while registering Endpoint : "  + str(je.getMessage()))
            response = None
            
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code != 200):            
                self.handleHttpErrorCode(response.code, responseData)
                return None
            else:
                return endpoint        
        return None
    
    def registerApplicationEndpoint(self):
         # identifiers and attributes
        marketingDatabase = MarketingDatabase()
        marketingDatabase.name = self.config.getUBXApplicationEndpointMarketingDBName()
        idents = self.config.getUBXApplicationEndpointMarketingDBIdentifiers().split(",")
        for ident in idents:
            tokens = ident.split("|")
            if len(tokens) == 2:
                mdident = MarketingDatabaseIdentifier(tokens[0], tokens[1])
                marketingDatabase.identifiers.append(mdident)
            elif len(tokens) == 1:
                mdident = MarketingDatabaseIdentifier(tokens[0], "string")
                marketingDatabase.identifiers.append(mdident)
            else:
                self.csLogger.error("Invalid identifier: " + ident)
                return None        
        
        attribs = self.config.getUBXApplicationEndpointMarketingDBAttributes().split(",")
        for attrib in attribs:
            mdtokens = attrib.split("|")
            if len(mdtokens) == 2:
                mdattrib = MarketingDatabaseAttribute(mdtokens[0], mdtokens[1])
                marketingDatabase.attributes.append(mdattrib)
            elif len(mdtokens) == 1:
                mdattrib = MarketingDatabaseAttribute(mdtokens[0],"string")
                marketingDatabase.attributes.append(mdattrib) 
            else:
                self.csLogger.error("Invalid attribute: " + attrib)
                return None
        
        marketingDatabaseDef = MarketingDatabasesDefinition()
        marketingDatabaseDef.marketingDatabases.append(marketingDatabase)
        marketingDatabasesDefinition = {}
        marketingDatabasesDefinition["marketingDatabasesDefinition"] = marketingDatabaseDef.toJSON()
        self.csLogger.debug(" marketing database definition endpoint : " + str(json.dumps(marketingDatabasesDefinition)))
        return self.registerEndpoint(marketingDatabasesDefinition,self.config.getUBXApplicationEndpointAuthenticationKey(),self.config.getUBXToolkitApplicationExternalID())
    
    def registerEventConsumerEndpoint(self):
        endpoint = Endpoint(self.config.getEventConsumerEndpointName(), self.config.getEventConsumerEndpointDesc(),
                            self.config.getEventConsumerEndpointProviderName())
        
        eventEndpoint = EventEndpoint()
        eventEndpoint.destination = EventDestination(True, DestinationType.PULL, None)
        
        eventEndpointType = EventEndpointType()
        eventEndpointType.event = eventEndpoint        
        endpoint.endpointTypes = eventEndpointType
        
        return self.registerEndpoint(endpoint, self.config.getEventConsumerAuthenticationKey())
            
    def registerSegmentProducerEndpoint(self):
        endpoint = Endpoint(self.config.getSegmentProducerEndpointName(), self.config.getSegmentProducerEndpointDesc(),
                            self.config.getSegmentProducerEndpointProviderName())

        segmentEndpoint = SegmentEndpoint()
        segmentEndpoint.source = SegmentSource(True, ProducerType.PUSH, None)
        
        segmentEndpointType = SegmentEndpointType()
        segmentEndpointType.segment = segmentEndpoint        
        endpoint.endpointTypes = segmentEndpointType
        
        # identifiers and attributes
        marketingDatabase = MarketingDatabase()
        marketingDatabase.name = self.config.getSegmentProducerMarketingDBName()
        idents = self.config.getSegmentProducerMarketingDBIdentifiers().split(",")
        for ident in idents:
            tokens = ident.split("|")
            if len(tokens) == 2:
                mdident = MarketingDatabaseIdentifier(tokens[0], tokens[1])
                marketingDatabase.identifiers.append(mdident)
            elif len(tokens) == 1:
                mdident = MarketingDatabaseIdentifier(tokens[0], "string")
                marketingDatabase.identifiers.append(mdident)
            else:
                self.csLogger.error("Invalid identifier: " + ident)
                return None        
        
        attribs = self.config.getSegmentProducerMarketingDBAttributes().split(",")
        for attrib in attribs:
            mdtokens = attrib.split("|")
            if len(mdtokens) == 2:
                mdattrib = MarketingDatabaseAttribute(mdtokens[0], mdtokens[1])
                marketingDatabase.attributes.append(mdattrib)
            elif len(mdtokens) == 1:
                mdattrib = MarketingDatabaseAttribute(mdtokens[0],"string")
                marketingDatabase.attributes.append(mdattrib) 
            else:
                self.csLogger.error("Invalid attribute: " + attrib)
                return None        
        
        marketingDatabaseDef = MarketingDatabasesDefinition()
        marketingDatabaseDef.marketingDatabases.append(marketingDatabase)        
        endpoint.marketingDatabasesDefinition = marketingDatabaseDef
        
        return self.registerEndpoint(endpoint, self.config.getSegmentProducerAuthenticationKey())

    def registerSegmentConsumerEndpoint(self):
        endpoint = Endpoint(self.config.getSegmentConsumerEndpointName(), self.config.getSegmentConsumerEndpointDesc(),
                            self.config.getSegmentConsumerEndpointProviderName())

        segmentEndpoint = SegmentEndpoint()
        segmentEndpoint.destination = SegmentDestination(True, DestinationType.PULL, None)
        
        segmentEndpointType = SegmentEndpointType()
        segmentEndpointType.segment = segmentEndpoint        
        endpoint.endpointTypes = segmentEndpointType
        
        # identifiers and attributes
        marketingDatabase = MarketingDatabase()
        marketingDatabase.name = self.config.getSegmentConsumerMarketingDBName()
        idents = self.config.getSegmentConsumerMarketingDBIdentifiers().split(",")
        for ident in idents:
            tokens = ident.split("|")
            if len(tokens) == 2:
                mdident = MarketingDatabaseIdentifier(tokens[0], tokens[1])
                marketingDatabase.identifiers.append(mdident)
            elif len(tokens) == 1:
                mdident = MarketingDatabaseIdentifier(tokens[0], "string")
                marketingDatabase.identifiers.append(mdident)
            else:
                self.csLogger.error("Invalid identifier: " + ident)
                return None        
        
        attribs = self.config.getSegmentConsumerMarketingDBAttributes().split(",")
        for attrib in attribs:
            mdtokens = attrib.split("|")
            if len(mdtokens) == 2:
                mdattrib = MarketingDatabaseAttribute(mdtokens[0], mdtokens[1])
                marketingDatabase.attributes.append(mdattrib)
            elif len(mdtokens) == 1:
                mdattrib = MarketingDatabaseAttribute(mdtokens[0],"string")
                marketingDatabase.attributes.append(mdattrib) 
            else:
                self.csLogger.error("Invalid attribute: " + attrib)
                return None        
        
        marketingDatabaseDef = MarketingDatabasesDefinition()
        marketingDatabaseDef.marketingDatabases.append(marketingDatabase)        
        endpoint.marketingDatabasesDefinition = marketingDatabaseDef
        
        return self.registerEndpoint(endpoint, self.config.getSegmentConsumerAuthenticationKey())

    def getEndpoints(self, authkey):
        httpClient = HTTPClient(self.config);
        url = self.getEndpointServiceURL()        
        headers = {'Authorization': 'Bearer ' + authkey }
        
        try:
            handler = UBXHTTPErrorProcessor()
            response = httpClient.sendRestRequest(url, None, headers, handler)
        except URLError, e:
            self.csLogger.error(str(e))
            response = None
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None

            
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code == 200):
                if (responseData != ""):
                    getEndpointsResponse = GetEndpointsResponse(response.code, responseData)
                    endpoints = getEndpointsResponse.getEndpoints()                    
                    if (endpoints is None):                    
                        self.csLogger.info("No endpoints returned")                    
                    return endpoints        
            else:
                self.handleHttpErrorCode(response.code, responseData)        
        return None

    def getEndpointByName(self, authkey, endpointName):
        endpoints = self.getEndpoints(authkey)
        if (endpoints is None):
            return None
        for endpoint in endpoints:
            if (endpoint.name == endpointName):
                return endpoint
        return None

        
    ##################################################################################
    # Segments
    ##################################################################################       
    def getSegments(self, authkey):
        httpClient = HTTPClient(self.config);
        url = self.getEndpointServiceURL() + "?segment=true&source=true&loadSegments=true&endpointId=" + self.config.getSegmentProducerEndpointID()
        
        headers = {'Authorization': 'Bearer ' + authkey }
        
        try:
            handler = UBXHTTPErrorProcessor()
            response = httpClient.sendRestRequest(url, None, headers, handler)
        except URLError, e:
            self.handleURLErrorException(e)
            response = None    
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            raise je
           
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code == 200):
                if (responseData != ""):
                    getSegmentsResponse = GetSegmentsResponse(response.code, responseData)
                    segments = getSegmentsResponse.getSegments()                    
                    if (segments is  None):                    
                        self.csLogger.info("No segments returned")
                    
                    return segments        
            else:
                self.handleHttpErrorCode(response.code, responseData)               
        
        return None

    def getSegmentDetail(self, authkey, segmentId):
        httpClient = HTTPClient(self.config);
        url = self.getEndpointServiceURL() + self.config.getSegmentProducerEndpointID() + "/segments/" + segmentId
        self.csLogger.debug("HTTP Request=" + url)
        headers = {'Authorization': 'Bearer ' + authkey }
        
        try:
            handler = UBXHTTPErrorProcessor()
            response = httpClient.sendRestRequest(url, None, headers, handler)
        except URLError, e:
            self.handleURLErrorException(e)
            response = None    
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            raise je
           
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code == 200):
                if (responseData != ""):
                    getSegmentDetailsResponse = GetSegmentDetailsResponse(response.code, responseData)
                    segment = getSegmentDetailsResponse.getSegment()                    
                    if (segment is  None):                    
                        self.csLogger.info("Segment not found")                    
                    return segment        
            else:
                self.handleHttpErrorCode(response.code, responseData)               
        
        return None

    
    def addSegments(self, segments):
        httpClient = HTTPClient(self.config)
        headers = {'Authorization': 'Bearer ' + self.config.getSegmentProducerAuthenticationKey(),
                   'Content-Type': 'application/json',
                   'Accept-Charset': 'UTF-8'}
                
        segmentData = []                
        for segment in segments:
            segmentData.append(segment.toJSON())                
        data = json.dumps(segmentData)
                
        url = self.getEndpointServiceURL() + self.config.getSegmentProducerEndpointID() + "/segments"
                
        self.csLogger.debug("HTTP Request=" + url)
        
        try:            
            response = httpClient.sendRestRequest(url, data, headers, None)
            
        except URLError, e:
            self.handleURLErrorException(e)
            response = None            
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            raise je
            
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code != 200):            
                self.handleHttpErrorCode(response.code, responseData)
                
    def replaceSegments(self, segments):
        httpClient = HTTPClient(self.config)
        headers = {'Authorization': 'Bearer ' + self.config.getSegmentProducerAuthenticationKey(),
                   'Content-Type': 'application/json',
                   'Accept-Charset': 'UTF-8'}
                
        segmentData = []                
        for segment in segments:
            segmentData.append(segment.toJSON())                
        data = json.dumps(segmentData)
                
        url = self.getEndpointServiceURL() + self.config.getSegmentProducerEndpointID() + "/segments"                
        self.csLogger.debug("HTTP Request=" + url)
        
        try:            
            response = httpClient.sendPutRequest(url, data, headers, None)
            
        except URLError, e:
            self.handleURLErrorException(e)
            response = None            
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            raise je
            
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code != 200):            
                self.handleHttpErrorCode(response.code, responseData)
                
    def deleteSegments(self):
        httpClient = HTTPClient(self.config);
        headers = {'Authorization': 'Bearer ' + self.config.getSegmentProducerAuthenticationKey() }
        url = self.getEndpointServiceURL() + self.config.getSegmentProducerEndpointID() + "/segments"                
        self.csLogger.debug("HTTP Request=" + url)
        
        try:
            response = httpClient.sendDeleteRequest(url, None, headers, None)
        except URLError, e:
            self.handleURLErrorException(e)
            response = None            
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            raise je
        
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code == 200):
                return None
            else:
                self.handleHttpErrorCode(response.code, responseData)
                    
        return None  
    
    def deleteSegment(self, segmentId):
        httpClient = HTTPClient(self.config);
        headers = {'Authorization': 'Bearer ' + self.config.getSegmentProducerAuthenticationKey() }
        url = self.getEndpointServiceURL() + self.config.getSegmentProducerEndpointID() + "/segments/"
        url = url + str(segmentId)                        
        self.csLogger.debug("HTTP Request=" + url)
        
        try:
            response = httpClient.sendDeleteRequest(url, None, headers, None)
        except URLError, e:
            self.handleURLErrorException(e)
            response = None
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            raise je            
            
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code == 200):
                return None
            else:
                self.handleHttpErrorCode(response.code, responseData)
                    
        return None                   
        
    ##################################################################################
    # Jobs
    ##################################################################################       
    def getJobs(self, authkey, jobCategory, endpointId, status):
        httpClient = HTTPClient(self.config);
        url = self.getJobsServiceURL() + jobCategory + "?endpointId=" + str(endpointId)
        
        if (status is not None):
            url = url + "&status=" + status
        self.csLogger.debug("HTTP Request=" + url)
        
        headers = {'Authorization': 'Bearer ' + authkey }
        
        try:
            handler = UBXHTTPErrorProcessor()
            response = httpClient.sendRestRequest(url, None, headers, handler)
        except URLError, e:
            self.handleURLErrorException(e)
            response = None
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            raise je
            
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            jobList = []
            if (response.code == 200):
                if (responseData != ""):
                    getJobsResponse = GetJobsResponse(response.code, responseData)
                    jobList = getJobsResponse.getJobList()                    
                    if (jobList is None or len(jobList) == 0):                    
                        self.csLogger.info("No jobs returned.")
                    
                    return jobList        
            elif (response.code == 404):
                # no jobs found
                if (status is not None):
                    self.csLogger.info("No jobs found with status " + status)    
                else:
                    self.csLogger.info("No jobs found." )
                return jobList
            else:
                self.handleHttpErrorCode(response.code, responseData)              
        
        return None
    
    def getJob(self, authkey, jobCategory, jobId):
        httpClient = HTTPClient(self.config);
        url = self.getJobsServiceURL() + jobCategory + "/" + str(jobId)
        
        headers = {'Authorization': 'Bearer ' + authkey }
        
        try:
            handler = UBXHTTPErrorProcessor()
            response = httpClient.sendRestRequest(url, None, headers, handler)
        except URLError, e:
            self.handleURLErrorException(e)
            response = None
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            raise je
            
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code == 200):
                if (responseData != ""):
                    getJobResponse = GetJobResponse(response.code, responseData)
                    job  = getJobResponse.getJob()                    
                    if (job is None):
                        self.csLogger.error("Job not found. JobID = " + str(jobId))                    
                    return job        
            else:
                self.handleHttpErrorCode(response.code, responseData)
        
        return None
    
    def setJobStatus(self, authkey, jobId, status):
        httpClient = HTTPClient(self.config)
        headers = {'Authorization': 'Bearer ' + authkey,
                   'Content-Type': 'application/json',
                   'Accept-Charset': 'UTF-8'}
                            
        url = self.getJobsServiceURL() + str(jobId) + "/status/" + status.lower()                
        self.csLogger.debug("HTTP Request=" + url)
        
        try:            
            response = httpClient.sendPutRequest(url, None, headers, None)
            
        except URLError, e:
            self.handleURLErrorException(e)
            response = None            
        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None            
            raise je
        
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code != 200):            
                self.handleHttpErrorCode(response.code, responseData)
                
    
    def postSegmentData(self, jobId, segmentDataFile):
        httpClient = HTTPClient(self.config)
        headers = {'Authorization': 'Bearer ' + self.config.getSegmentProducerAuthenticationKey(),
                   'Content-Type': 'text/plain',
                   'Accept-Charset': 'UTF-8'}
                            
        url = self.getJobsServiceURL() + str(jobId) + "/data"                
        self.csLogger.debug("HTTP Request=" + url)
        
        # Read CSV file as data        
        f =  open(segmentDataFile, 'rU')
        try:                
            lines = f.readlines()
        finally:
            f.close()

        data = ""
        for line in lines:
            data = data + line

        try:            
            response = httpClient.sendRestRequest(url, data, headers, None)
            
        except URLError, e:
            self.handleURLErrorException(e)
            response = None

        except Exception, je:
            self.csLogger.error(str(je.getMessage()))
            response = None
            raise je            
            
        if (response is not None):
            responseData = response.read()
            self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
            if (response.code != 200):            
                self.handleHttpErrorCode(response.code, responseData)
                return False
            return True
        return False
    
    def downloadSegmentData(self, job):
        # https://ubx-qa1-api.adm01.com/v1/jobs/7852/segmentDataFiles/45|641|10001_1.segment
        #    return None
                  
        
        httpClient = HTTPClient(self.config)
        headers = {'Authorization': 'Bearer ' + self.config.getSegmentConsumerAuthenticationKey(),
                   'Accept-Charset': 'UTF-8'}

        bCreatedNow = False
        count = 1
        for segmentDataFile in job.segmentDataFiles:                            
            url = self.getJobsServiceURL() + str(job.jobId) + "/segmentDataFiles/" + pathname2url(segmentDataFile)                        
            self.csLogger.debug("HTTP Request=" + url)
    
            try:
                handler = UBXHTTPErrorProcessor()                
                response = httpClient.sendRestRequest(url, None, headers, handler)
            except URLError, e:
                self.handleURLErrorException(e)
                response = None
            except Exception, je:
                self.csLogger.error(str(je.getMessage()))
                response = None
                raise je
            
            if (response is not None):
                responseData = response.read()
                self.csLogger.debug("HTTP Response Code=" + str(response.code) + ", msg=" + responseData)
                if (response.code == 200):
                    if (responseData != ""):
                        destSegmentName = job.destinationSegmentName
                        if (destSegmentName is None):
                            destSegmentName = "SegmentData"
                        
                        destSegmentName = NormalizeUtils.toValidFileName(destSegmentName)              
                        csvFilepath = self.config.getSegmentDownloadFolder() + os.sep + destSegmentName + ".csv"
                        self.csLogger.debug("csvFilePath before moving: " + csvFilepath + ", bCreatedNow : " + str(bCreatedNow))
                        if os.path.exists(csvFilepath) and bCreatedNow == False:
                            if (self.config.getArchiveDonwloadedSegments()):
                                # move to archive folder
                                now = int(round(time.time() * 1000))  
                                archiveFilepath = self.config.getArchiveDonwloadedSegmentsFolder() + os.sep + destSegmentName + "_" + str(now) + ".csv"
                                self.csLogger.info("Move current audience file to archive: " + archiveFilepath)
                                shutil.move(csvFilepath, archiveFilepath)
                        
                        
                  
                        self.csLogger.info("Writing audience file to: " + csvFilepath)
                        csvFile = open(csvFilepath, "ab")
                        bCreatedNow = True
                        if(count > 1):
                            responseData = re.sub(r'^[^\n]*\n', '', responseData)
                                     
                        csvFile.write(responseData)
                        count = count + 1
                        csvFile.close()
                    else:
                        self.csLogger.warn("No audience data was found. A new file will not be created.")
                else:
                    self.handleHttpErrorCode(response.code, responseData)                           
        
                                
class EventFile:
    def __init__(self, id):
        self.id = id
    
    def getId(self):
        return self.id
    
class GetEventFileListResponse:
    
    def __init__(self, responseCode, responseData):        
        self.responseCode = responseCode   
        self.fileList = []     
        self.fileList = json.loads(responseData)
            
    def getResponseCode(self):
        return self.responseCode    
        
    def getFileList(self):
        if (self.fileList is not None):
            return self.fileList
        return None
        
class GetEventFileResponse:
    def __init__(self, responseCode, responseData):        
        self.responseCode = responseCode
        self.fileContent = responseData
            
    def getResponseCode(self):
        return self.responseCode    
        
    def getFileContent(self):
        if (self.fileContent is not None):
            return self.fileContent
        return None        

class GetSegmentsResponse:    
    def __init__(self, responseCode, responseData):        
        self.responseCode = responseCode   
        self.segments = []     
        endpoints = json.loads(responseData)        
        for endpoint in endpoints:
            if (endpoint["segments"] is not None):            
                segmentitems = endpoint["segments"]["list"]
                for item in segmentitems:
                    segment = Segment(None, None, None)
                    segment.fromJSON(item)
                    self.segments.append(segment)
                            
    def getResponseCode(self):
        return self.responseCode    
        
    def getSegments(self):
        if (self.segments is not None):
            return self.segments
        return None

class GetSegmentDetailsResponse:
    def __init__(self, responseCode, responseData):        
        self.responseCode = responseCode       
        self.segment = Segment(None, None, None)        
        self.segment.fromJSON(json.loads(responseData))      
                            
    def getResponseCode(self):
        return self.responseCode    
        
    def getSegment(self):
        return self.segment
    
class GetJobsResponse:    
    def __init__(self, responseCode, responseData):        
        self.responseCode = responseCode   
        self.joblist = []     
        jobs = json.loads(responseData)
        for item in jobs:
            job = Job()
            job.fromJSON(item)
            self.joblist.append(job)
            
            
    def getResponseCode(self):
        return self.responseCode    
        
    def getJobList(self):
        if (self.joblist is not None):
            return self.joblist
        return None

class GetJobResponse:    
    def __init__(self, responseCode, responseData):        
        self.responseCode = responseCode       
        self.job = json.loads(responseData)
            
    def getResponseCode(self):
        return self.responseCode    
        
    def getJob(self):
        if (self.job is not None):
            return self.job
        return None

class GetEndpointsResponse:    
    def __init__(self, responseCode, responseData):        
        self.responseCode = responseCode
        self.endpoints = []
        endpoints = json.loads(responseData)
        for item in endpoints:
            endpoint = Endpoint()
            endpoint.fromJSON(item)
            self.endpoints.append(endpoint)     
                            
    def getResponseCode(self):
        return self.responseCode    
        
    def getEndpoints(self):
        if (self.endpoints is not None):
            return self.endpoints
        return None

    
class UBXHTTPErrorProcessor(HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
    
    https_response = http_response
