##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import gzip
import zipfile
import os

def unzip(zipfilepath, destfolder, logger=None):
    zfile = zipfile.ZipFile(zipfilepath)
    for name in zfile.namelist():
        (dirname, filename) = os.path.split(name)
        if (logger is not None):
            logger.debug("Decompressing " + filename + " to " + destfolder)
        if not os.path.exists(destfolder):
            os.makedirs(destfolder)
        outfilepath = destfolder + os.sep + filename
        outfile = open(outfilepath, "wb")
        outfile.write(zfile.read(name))
        outfile.close()
    zfile.close()
    zfile = None

def gunzip(zipfilepath, destfolder, logger=None):
    zfile = gzip.open(zipfilepath, 'rb')
    (dirname, filename) = os.path.split(zipfilepath)
    name = os.path.splitext(filename)[0]
    if (logger is not None):
         logger.debug("Decompressing " + name + " to " + destfolder)
    if not os.path.exists(destfolder):
         os.makedirs(destfolder)
    outfilepath = destfolder + os.sep + name
    outfile = open(outfilepath, "wb")
    outfile.write(zfile.read())
    outfile.close()
    zfile.close()
    zfile = None
