-----------------------------------------------------------------------------
-- Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
-- NOTICE: This file contains material that is confidential and proprietary to
-- Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
-- industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
-- Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.
-----------------------------------------------------------------------------
CREATE TABLE UBX_EmailSend (
	RecordID		number(19) NOT NULL,
	Provider		VARCHAR2(64) NULL,
	EndpointSource	VARCHAR2(64) NULL,
	Channel			VARCHAR2(64) NULL,
	X1ID			VARCHAR2(64) NULL,
	ContactId		VARCHAR2(64) NULL,
	Email			VARCHAR2(64) NULL,
	EventCode		VARCHAR2(64) NOT NULL,
	EventTimeStamp	TIMESTAMP NOT NULL,
	EventNameSpace	VARCHAR2(64) NULL,
	EventVersion	VARCHAR2(64) NULL,			
	EventName		VARCHAR2(64) NULL,
	Description		VARCHAR2(128) NULL,
	MessageId		number(19) NULL,
	MailingTemplateId number(19) NULL,
	ReportId		VARCHAR2(64) NULL,	
	SubjectLine 	VARCHAR2(256) NULL,
	MessageName 	VARCHAR2(256) NULL,
	DocType	    	VARCHAR2(64) NULL,
	SendType    	VARCHAR2(64) NULL,
	EventId     	VARCHAR2(64) NULL,
    CONSTRAINT tUBX_EmailSend_PK PRIMARY KEY (RecordID)
);

CREATE TABLE UBX_EmailOpen (
	RecordID		number(19) NOT NULL,
	Provider		VARCHAR2(64) NULL,
	EndpointSource	VARCHAR2(64) NULL,
	Channel			VARCHAR2(64) NULL,
	X1ID			VARCHAR2(64) NULL,
	ContactId		VARCHAR2(64) NULL,
	Email			VARCHAR2(64) NULL,
	EventCode		VARCHAR2(64) NOT NULL,
	EventTimeStamp	TIMESTAMP NOT NULL,
	EventNameSpace	VARCHAR2(64) NULL,
	EventVersion	VARCHAR2(64) NULL,				
	EventName		VARCHAR2(64) NULL,
	Description		VARCHAR2(128) NULL,
	MessageId		number(19) NULL,
	MailingTemplateId number(19) NULL,
	ReportId		VARCHAR2(64) NULL,	
	SubjectLine 	VARCHAR2(256) NULL,
	MessageName 	VARCHAR2(256) NULL,
	DocType	    	VARCHAR2(64) NULL,
	EventId     	VARCHAR2(64) NULL,
    CONSTRAINT tUBX_EmailOpen_PK PRIMARY KEY (RecordID)
);

CREATE TABLE UBX_EmailClick (
	RecordID		number(19) NOT NULL,
	Provider		VARCHAR2(64) NULL,
	EndpointSource	VARCHAR2(64) NULL,
	Channel			VARCHAR2(64) NULL,
	X1ID			VARCHAR2(64) NULL,
	ContactId		VARCHAR2(64) NULL,
	Email			VARCHAR2(64) NULL,
	EventCode		VARCHAR2(64) NOT NULL,			
	EventTimeStamp	TIMESTAMP NOT NULL,
	EventNameSpace	VARCHAR2(64) NULL,
	EventVersion	VARCHAR2(64) NULL,
	EventName		VARCHAR2(64) NULL,
	Description		VARCHAR2(128) NULL,
	MessageId		number(19) NULL,
	MailingTemplateId number(19) NULL,
	ReportId		VARCHAR2(64) NULL,	
	SubjectLine 	VARCHAR2(256) NULL,
	MessageName 	VARCHAR2(256) NULL,
	DocType	    	VARCHAR2(64) NULL,
	ClickUrl    	VARCHAR2(128) NULL,
	UrlDescription 	VARCHAR2(128) NULL,
	EventId     	VARCHAR2(64) NULL,
    CONSTRAINT tUBX_EmailClick_PK PRIMARY KEY (RecordID)
);

CREATE TABLE UBX_EmailBounce (
	RecordID		number(19) NOT NULL,
	Provider		VARCHAR2(64) NULL,
	EndpointSource	VARCHAR2(64) NULL,
	Channel			VARCHAR2(64) NULL,
	X1ID			VARCHAR2(64) NULL,
	ContactId		VARCHAR2(64) NULL,
	Email			VARCHAR2(64) NULL,
	EventCode		VARCHAR2(64) NOT NULL,			
	EventTimeStamp	TIMESTAMP NOT NULL,
	EventNameSpace	VARCHAR2(64) NULL,
	EventVersion	VARCHAR2(64) NULL,
	EventName		VARCHAR2(64) NULL,
	Description		VARCHAR2(128) NULL,
	MessageId		number(19) NULL,
	MailingTemplateId number(19) NULL,
	ReportId		VARCHAR2(64) NULL,	
	SubjectLine 	VARCHAR2(256) NULL,
	MessageName 	VARCHAR2(256) NULL,
	DocType	    	VARCHAR2(64) NULL,
	BounceType    	VARCHAR2(64) NULL,
	EventId     	VARCHAR2(64) NULL,
    CONSTRAINT tUBX_EmailBounce_PK PRIMARY KEY (RecordID)
);

-- UBX_EmailSend Sequence
CREATE SEQUENCE UBX_SEQ_EMAILSEND MINVALUE 1 MAXVALUE 99999999999 START WITH 1 INCREMENT BY 1 NOCACHE;
 
CREATE OR REPLACE TRIGGER UBX_INS_EMAILSEND
     BEFORE INSERT ON UBX_EmailSend
     FOR EACH ROW WHEN (new.RecordID IS NULL)
     BEGIN
     	:new.RecordId:=UBX_SEQ_EMAILSEND.nextval;
     END;
/
 
-- UBX_EmailOpen Sequence
CREATE SEQUENCE UBX_SEQ_EMAILOPEN MINVALUE 1 MAXVALUE 99999999999 START WITH 1 INCREMENT BY 1 NOCACHE;
 
CREATE OR REPLACE TRIGGER UBX_INS_EMAILOPEN
     BEFORE INSERT ON UBX_EmailOpen
     FOR EACH ROW WHEN (new.RecordID IS NULL)
     BEGIN
     	:new.RecordId:=UBX_SEQ_EMAILOPEN.nextval;
     END;
/

-- UBX_EmailClick Sequence
CREATE SEQUENCE UBX_SEQ_EMAILCLICK MINVALUE 1 MAXVALUE 99999999999 START WITH 1 INCREMENT BY 1 NOCACHE;
 
CREATE OR REPLACE TRIGGER UBX_INS_EMAILCLICK
     BEFORE INSERT ON UBX_EmailClick
     FOR EACH ROW WHEN (new.RecordID IS NULL)
     BEGIN
     	:new.RecordId:=UBX_SEQ_EMAILCLICK.nextval;
     END;
/  

-- UBX_EmailBounce Sequence
CREATE SEQUENCE UBX_SEQ_EMAILBOUNCE MINVALUE 1 MAXVALUE 99999999999 START WITH 1 INCREMENT BY 1 NOCACHE;
 
CREATE OR REPLACE TRIGGER UBX_INS_EMAILBOUNCE
     BEFORE INSERT ON UBX_EmailBounce
     FOR EACH ROW WHEN (new.RecordID IS NULL)
     BEGIN
     	:new.RecordId:=UBX_SEQ_EMAILBOUNCE.nextval;
     END;
/  
