##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import os
from com.ibm.emm.integration.log import CSLogger
from cfg import Config
from java.lang import String
from conf.cfg import getCUHome

class UBXConfig(Config):
    
    PROPERTIES_UBX_API_SERVICE_URL="ubx.api.service.url"
    
    PROPERITES_UBX_TOOLKIT_APPLICATION_ID="ubx.toolkit.application.external.app.id"
    PROPERTIES_UBX_APPLICATION_ENDPOINT_MARKETINGDB_NAME="ubx.application.endpoint.marketingdb.name"
    PROPERTIES_UBX_APPLICATION_ENDPOINT_MARKETINGDB_IDENTIFIERS="ubx.application.endpoint.marketingdb.identifiers"
    PROPERTIES_UBX_APPLICATION_ENDPOINT_MARKETINGDB_ATTRIBUTES="ubx.application.endpoint.marketingdb.attributes"
    PROPERTIES_UBX_APPLICATION_ENDPOINT_AUTHENTICATION_KEY="ubx.application.endpoint.authentication.key"
    
    PROPERTIES_UBX_ENDPOINT_EVENTFILES_NUMFILES_IN_LIST="ubx.endpoint.eventfiles.numFilesInList"
    
    PROPERTIES_UBX_EVENT_CONSUMER_ENDPOINT_NAME="ubx.event.consumer.endpoint.name"
    PROPERTIES_UBX_EVENT_CONSUMER_ENDPOINT_DESC="ubx.event.consumer.endpoint.desc"
    PROPERTIES_UBX_EVENT_CONSUMER_ENDPOINT_PROVIDER_NAME="ubx.event.consumer.endpoint.provider"
    PROPERTIES_UBX_EVENT_CONSUMER_AUTHENTICATION_KEY="ubx.event.consumer.endpoint.authentication.key"
    PROPERTIES_UBX_EVENT_DELETE_FILES_FROM_SERVER="ubx.event.consumer.deleteFilesFromServer"
    PROPERTIES_ENCODING = "encoding"
    
    PROPERTIES_LOCAL_DOWNLOAD_DIR= "local.download.dir"; 
    
    PROPERTIES_ONERROR_OVERALL_RETRY_TIME= "onerror.overall.retry.time"
    PROPERTIES_ONERROR_RETRY_NUM= "onerror.retry.num"
    PROPERTIES_ONERROR_SLEEP_BETWEEN_RETRIES = "onerror.sleep.betweeen.retries"    
    
    # The name of the endpoint that produce audiences
    PROPERTIES_UBX_SEGMENT_PROD_ENDPOINT_ID="ubx.audience.producer.endpoint.id"
    PROPERTIES_UBX_SEGMENT_PROD_ENDPOINT_NAME="ubx.audience.producer.endpoint.name"
    PROPERTIES_UBX_SEGMENT_PROD_ENDPOINT_DESC="ubx.audience.producer.endpoint.desc"
    PROPERTIES_UBX_SEGMENT_PROD_ENDPOINT_PROVIDER_NAME="ubx.audience.producer.endpoint.provider"
    PROPERTIES_UBX_SEGMENT_PROD_AUTHENTICATION_KEY="ubx.audience.producer.endpoint.authentication.key"
    PROPERTIES_UBX_SEGMENT_PROD_MARKETINGDB_NAME="ubx.audience.producer.endpoint.marketingdb.name"
    PROPERTIES_UBX_SEGMENT_PROD_MARKETINGDB_IDENTIFIERS="ubx.audience.producer.endpoint.marketingdb.identifiers"
    PROPERTIES_UBX_SEGMENT_PROD_MARKETINGDB_ATTRIBUTES="ubx.audience.producer.endpoint.marketingdb.attributes"
    
    PROPERTIES_UBX_SEGMENT_PROD_SEGMENT_PUBLISH_FOLDER="ubx.audience.producer.audiencePublishFolder"
    PROPERTIES_UBX_SEGMENT_PROD_MOVE_FILE_TO_DELIVERED_FOLDER="ubx.audience.producer.moveFileToDeliveredFolder"
    PROPERTIES_UBX_SEGMENT_PROD_JOB_WAITING_FOR_DATA_TIMEOUT_IN_MINS="ubx.audience.producer.jobWaitingForDataTimeoutInMinutes"
    
    # Audience Consumer end point
    PROPERTIES_UBX_SEGMENT_CONSUMER_ENDPOINT_ID="ubx.audience.consumer.endpoint.id"
    PROPERTIES_UBX_SEGMENT_CONSUMER_ENDPOINT_NAME="ubx.audience.consumer.endpoint.name"
    PROPERTIES_UBX_SEGMENT_CONSUMER_ENDPOINT_DESC="ubx.audience.consumer.endpoint.desc"
    PROPERTIES_UBX_SEGMENT_CONSUMER_ENDPOINT_PROVIDER_NAME="ubx.audience.consumer.endpoint.provider"
    PROPERTIES_UBX_SEGMENT_CONSUMER_SEGMENT_DOWNLOAD_FOLDER="ubx.audience.consumer.audienceDownloadFolder"
    PROPERTIES_UBX_SEGMENT_CONSUMER_AUTHENTICATION_KEY="ubx.audience.consumer.endpoint.authentication.key"    
    PROPERTIES_UBX_SEGMENT_CONSUMER_ARCHIVE_DOWNLOADED_SEGMENTS="ubx.audience.consumer.archiveDownloadedAudiences"
    PROPERTIES_UBX_SEGMENT_CONSUMER_MARKETINGDB_NAME="ubx.audience.consumer.endpoint.marketingdb.name"
    PROPERTIES_UBX_SEGMENT_CONSUMER_MARKETINGDB_IDENTIFIERS="ubx.audience.consumer.endpoint.marketingdb.identifiers"
    PROPERTIES_UBX_SEGMENT_CONSUMER_MARKETINGDB_ATTRIBUTES="ubx.audience.consumer.endpoint.marketingdb.attributes"

    DEFAULT_CONFIG_FILE = "config.properties"    
    ROOT_SECTION = "ROOTSECTION"
    
    def __init__(self, cfgPath):             
        Config.__init__(self, cfgPath)
        self.csLogger = CSLogger.getCSLogger("conf.UBXConfig") 
       
    def isUrlConfigured(self, parmUrl):
        apiServiceUrl = self.getAPIServiceURL()
        if ( String(parmUrl).indexOf(apiServiceUrl) >= 0):
            return True
        else:
            return False
        
    def getProxyServer(self, url):
        if (not self.isUrlConfigured(url)):
            return None
        return Config.getProxyServer(self, url)        
           
    def getAPIServiceURL(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_API_SERVICE_URL)
    
    def getUBXToolkitApplicationExternalID(self):
        return self.getRequiredProperty(self.PROPERITES_UBX_TOOLKIT_APPLICATION_ID)
    
    def getUBXApplicationEndpointMarketingDBName(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_APPLICATION_ENDPOINT_MARKETINGDB_NAME)

    def getUBXApplicationEndpointMarketingDBIdentifiers(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_APPLICATION_ENDPOINT_MARKETINGDB_IDENTIFIERS)
    
    def getUBXApplicationEndpointMarketingDBAttributes(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_APPLICATION_ENDPOINT_MARKETINGDB_ATTRIBUTES)

    def getUBXApplicationEndpointAuthenticationKey(self):
        return self.getOptionalProperty(self.PROPERTIES_UBX_APPLICATION_ENDPOINT_AUTHENTICATION_KEY)
    
    def getEventConsumerEndpointName(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_EVENT_CONSUMER_ENDPOINT_NAME)
    
    def getEventConsumerEndpointDesc(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_EVENT_CONSUMER_ENDPOINT_DESC)
    
    def getEventConsumerEndpointProviderName(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_EVENT_CONSUMER_ENDPOINT_PROVIDER_NAME)

    def getEventConsumerAuthenticationKey(self):
        authKey = self.getUBXApplicationEndpointAuthenticationKey()
        if(authKey == None or len(authKey.strip())== 0):
            self.csLogger.debug("Application endpoint authentication key is not defined. Using event consumer authentication key " + str(self.getRequiredProperty(self.PROPERTIES_UBX_EVENT_CONSUMER_AUTHENTICATION_KEY)))
            return self.getRequiredProperty(self.PROPERTIES_UBX_EVENT_CONSUMER_AUTHENTICATION_KEY)
        else:
            self.csLogger.debug("Using Application endpoint authentication key " + str(authKey))
            return authKey

    def getEventFilesNumFilesInList(self):
        return self.getIntProperty(self.PROPERTIES_UBX_ENDPOINT_EVENTFILES_NUMFILES_IN_LIST)

    def isDeleteFilesFromServer(self):
        ret = self.getOptionalProperty(self.PROPERTIES_UBX_EVENT_DELETE_FILES_FROM_SERVER)
        if (ret is None):
            return True
        ret = ret.lower()
        if (ret == "false" or ret == "no"):
            return False
        return True
                    
    def getLocalDownloadDir(self):        
        ret = self.getRequiredProperty(self.PROPERTIES_LOCAL_DOWNLOAD_DIR)
        
        var = String('%CU_HOME%')
        ind = String(ret.upper()).indexOf(var);        
        if(ind>= 0):
            return getCUHome() + String(ret).substring(var.length());
        
        var = String('${CU_HOME}')
        ind = String(ret.upper()).indexOf(var);        
        if(ind>= 0):
            return getCUHome() + String(ret).substring(var.length());
        
        return ret

    def getOnErrorOverallRetryTime(self):
        return self.getIntProperty(self.PROPERTIES_ONERROR_OVERALL_RETRY_TIME)
    
    def getOnErrorRetryNum(self):
        return self.getIntProperty(self.PROPERTIES_ONERROR_RETRY_NUM)

    def getOnErrorSleepBetweenRetries(self):
        return self.getIntProperty(self.PROPERTIES_ONERROR_SLEEP_BETWEEN_RETRIES)

    def getSegmentProducerEndpointID(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_ENDPOINT_ID)

    def getSegmentProducerEndpointName(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_ENDPOINT_NAME)
    
    def getSegmentProducerEndpointDesc(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_ENDPOINT_DESC)
    
    def getSegmentProducerEndpointProviderName(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_ENDPOINT_PROVIDER_NAME)
    
    def getSegmentProducerAuthenticationKey(self):
        authKey = self.getUBXApplicationEndpointAuthenticationKey()
        if(authKey == None or len(authKey.strip())== 0):
            self.csLogger.debug("Application endpoint authentication key is not defined. Using Segment Producer authentication Key " + str(self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_AUTHENTICATION_KEY)))
            return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_AUTHENTICATION_KEY)
        else:
            self.csLogger.debug("Using Application authentication key " + str(authKey))
            return authKey
    
    def getSegmentProducerMarketingDBName(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_MARKETINGDB_NAME)

    def getSegmentProducerMarketingDBIdentifiers(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_MARKETINGDB_IDENTIFIERS)

    def getSegmentProducerMarketingDBAttributes(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_MARKETINGDB_ATTRIBUTES)


    def getSegmentPublishFolder(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_SEGMENT_PUBLISH_FOLDER)
    
    def getSegmentPublishedFolder(self):
        publishedDir = self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_SEGMENT_PUBLISH_FOLDER) + os.sep + "published"
        if not os.path.exists(publishedDir):
            os.makedirs(publishedDir)
        return publishedDir

    def getSegmentDeliveredFolder(self):
        deliveredDir = self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_PROD_SEGMENT_PUBLISH_FOLDER) + os.sep + "delivered"
        if not os.path.exists(deliveredDir):
            os.makedirs(deliveredDir)
        return deliveredDir
    
    def getMoveSegmentToDeliveredFolder(self):
        return self.getBoolProperty(self.PROPERTIES_UBX_SEGMENT_PROD_MOVE_FILE_TO_DELIVERED_FOLDER)
    
    def getJobWaitingForDataTimeout(self):
        return self.getIntProperty(self.PROPERTIES_UBX_SEGMENT_PROD_JOB_WAITING_FOR_DATA_TIMEOUT_IN_MINS)
    
    def getSegmentConsumerEndpointID(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_CONSUMER_ENDPOINT_ID)

    def getSegmentConsumerEndpointName(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_CONSUMER_ENDPOINT_NAME)
    
    def getSegmentConsumerEndpointDesc(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_CONSUMER_ENDPOINT_DESC)
    
    def getSegmentConsumerEndpointProviderName(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_CONSUMER_ENDPOINT_PROVIDER_NAME)


    def getSegmentDownloadFolder(self):
        downloadDir = self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_CONSUMER_SEGMENT_DOWNLOAD_FOLDER)
        if not os.path.exists(downloadDir):
            os.makedirs(downloadDir)
        return downloadDir

    def getSegmentConsumerAuthenticationKey(self):
        
        authKey = self.getUBXApplicationEndpointAuthenticationKey()
        if(authKey == None or len(authKey.strip())== 0):
            self.csLogger.debug("Application endpoint authentication key is not defined. Using Segment Consumer authentication Key " + str(self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_CONSUMER_AUTHENTICATION_KEY)))
            return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_CONSUMER_AUTHENTICATION_KEY)
        else:
            self.csLogger.debug("Using Application authentication key " + str(authKey))
            return authKey
    
    def getSegmentConsumerMarketingDBName(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_CONSUMER_MARKETINGDB_NAME)

    def getSegmentConsumerMarketingDBIdentifiers(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_CONSUMER_MARKETINGDB_IDENTIFIERS)

    def getSegmentConsumerMarketingDBAttributes(self):
        return self.getRequiredProperty(self.PROPERTIES_UBX_SEGMENT_CONSUMER_MARKETINGDB_ATTRIBUTES)
    
    def getArchiveDonwloadedSegments(self):
        return self.getBoolProperty(self.PROPERTIES_UBX_SEGMENT_CONSUMER_ARCHIVE_DOWNLOADED_SEGMENTS)
    
    def getArchiveDonwloadedSegmentsFolder(self):
        archiveDir = self.getSegmentDownloadFolder() + os.sep + "archive"
        if not os.path.exists(archiveDir):
            os.makedirs(archiveDir)
        return archiveDir
    
    def getEncoding(self):
        return self.getOptionalProperty(self.PROPERTIES_ENCODING)
