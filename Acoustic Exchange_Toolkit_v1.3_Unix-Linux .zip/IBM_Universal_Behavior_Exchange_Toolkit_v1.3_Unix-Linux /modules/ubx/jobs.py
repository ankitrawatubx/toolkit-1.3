##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015, 2016.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import simplejson as json

class JobCategory:
    SEGMENT_EXPORT = "SEGMENT_EXPORT"
    IDENTITIES_UPLOAD = "IDENTITIES_UPLOAD"
    
class JobStatus:
    WAITING_TO_RECIEVE_DATA = "WAITING_TO_RECIEVE_DATA"
    READY_FOR_DOWNLOAD = "READY_FOR_DOWNLOAD"
    COMPLETE = "COMPLETE"
    
class Job:    
    def __init__(self):        
        self.jobId = None
        self.jobName = None
        self.jobCategory = None
        self.status = None
        self.subStatus = None
        self.segmentDataFiles = []
        self.segmentDataFormat = None 
        self.destinationSegmentID = None
        destinationSegmentName = None
        destinationSegmentDescription = None
        destinationEndpointID = None
        exportCategory = None
        producerEndpointID = None
        producerSegmentID = None
        attributeMappings = []
        identityMappings = []
        
    def toJSON(self):
        payload = {}
        payload["jobId"] = self.jobId
        payload["jobName"] = self.jobName
        payload["jobCategory"] = self.jobCategory
        payload["status"] = self.status
        payload["subStatus"] = self.subStatus
        payload["accountId"] = self.accountId
        payload["segmentDataFiles"] = self.segmentDataFiles 
        payload["segmentDataFormat"] = self.segmentDataFormat        
        payload["destinationSegmentID"] = self.destinationSegmentID
        payload["destinationSegmentName"] = self.destinationSegmentName
        payload["destinationSegmentDescription"] = self.destinationSegmentDescription
        payload["destinationEndpointID"] = self.destinationEndpointID
        payload["exportCategory"] = self.exportCategory
        payload["producerEndpointID"] = self.producerEndpointID
        payload["producerSegmentID"] = self.producerSegmentID
        payload["attributeMappings"] = self.attributeMappings
        payload["identityMappings"] = self.identityMappings
        
        return payload
    
    def fromJSON(self, payload):
        self.jobId = payload["jobId"]
        self.jobName = payload["jobName"]
        self.jobCategory = payload["jobCategory"]
        self.status = payload["status"]
        self.subStatus = payload["subStatus"]
        self.accountId = payload["accountId"]
        self.segmentDataFiles = payload["segmentDataFiles"]
        self.segmentDataFormat = payload["segmentDataFormat"]          
        self.destinationSegmentID = payload["destinationSegmentID"] 
        self.destinationSegmentName = payload["destinationSegmentName"] 
        self.destinationSegmentDescription = payload["destinationSegmentDescription"] 
        self.destinationEndpointID = payload["destinationEndpointID"] 
        self.exportCategory = payload["exportCategory"] 
        self.producerEndpointID = payload["producerEndpointID"] 
        self.producerSegmentID = payload["producerSegmentID"]
        self.attributeMappings = payload["attributeMappings"]
        self.identityMappings = payload["identityMappings"] 

        
