##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015, 2016.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import sys
import getopt


from conf.cfg import getAbsolutePath
from conf.ubxconfig import UBXConfig
from ubx.apimanager import UBXAPIManager
from ubx.endpoints import *

from com.ibm.emm.integration.log import CSLogger
from java.lang import Exception

def RegisterEndpoint(argv):    

    # Parsing command line arguments                
    configPropsFileName = None
    #endpointType = None
       
    usage = 'Usage: registerEndpoint -t <endpointtype> [-c <config properties file>]'    
    try:
        opts, args = getopt.getopt(argv,"hc",["config="])
    except getopt.GetoptError:
        print usage
        sys.exit(64)
    for opt, arg in opts:   
        if opt in ("-h", "--help"):
            print usage
            sys.exit(0)     
        elif opt in ("-c", "--config"):
            configPropsFileName = getAbsolutePath(arg)                
        #elif opt in ("-t", "--type"):
        #    endpointType = arg    
    
    try:       
        # Initializing, loading configuration, etc.
        csLogger = CSLogger.setScript("registerEndpoint")
        csLogger = CSLogger.getCSLogger("scripts.registerEndpoint")
        
        #if (endpointType is None):
        #    csLogger.error('You must specify the end point type to register (audienceProducer, audienceConsumer or eventConsumer)')
        #    sys.exit(64) 
        
        csLogger.info("***** Register Endpoint script script started. *****")          
        config = UBXConfig(configPropsFileName)
        
        # Calling the UBX API to register the endpoint        
        apimanager = UBXAPIManager(config)
        endpoint = None
        applicationEndpointAuthKey = config.getUBXApplicationEndpointAuthenticationKey()
        
        if(applicationEndpointAuthKey == None or len(applicationEndpointAuthKey.strip()) == 0):
            csLogger.error("Application endpoint authentication key not found. Please specify correct value for ubx.application.endpoint.authentication.key in configuration file.")
            sys.exit(64)
        
        
        endpoint = apimanager.registerApplicationEndpoint()
        if (endpoint == None):
            csLogger.error('Register Endpoint failed.')
            sys.exit(64)
        
        endpoints = apimanager.getEndpoints(config.getUBXApplicationEndpointAuthenticationKey())
        if(endpoints == None):
            csLogger.error("Could not retrieve the endpoint definition by application endpoint authentication key")
            sys.exit(64)
        
        if(len(endpoints)!=1):
            csLogger.info("Expected one endpoint by supplied auth key ["+config.getUBXApplicationEndpointAuthenticationKey()+"]. Found " + len(endpoints) )
         
        for endpoint in endpoints:
            csLogger.info("Registered Endpoint ID: " + str(endpoint.id)) 
            csLogger.info("Please update the configuration file with the endpoint ID for:\n\tAudience Producer endpoint ID="+str(endpoint.id) + "\n\tAudience Consumer endpoint ID="+str(endpoint.id))
               
        csLogger.info('Register Endpoint script succeeded.')     

    except Exception, e:
        csLogger.error('Register Endpoint script terminating with error! ',e)                                         
                    
    finally:
        csLogger.info('***** Register Endpoint script completed. *****')  

if __name__ == '__main__':    
    RegisterEndpoint(sys.argv[1:])
