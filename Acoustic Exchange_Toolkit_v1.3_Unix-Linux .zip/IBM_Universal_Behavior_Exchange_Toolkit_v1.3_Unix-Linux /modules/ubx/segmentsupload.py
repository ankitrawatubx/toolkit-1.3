##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015, 2016.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import os
import sys
import getopt
import time
import csv

from conf.cfg import getAbsolutePath, getAppDataDir
from conf.ubxconfig import UBXConfig
from ubx.apimanager import UBXAPIManager
from ubx.segments import *
from ubx.jobs import *

from com.ibm.emm.integration.log import CSLogger
from java.lang import Exception

def UploadSegments(argv):    

    # Parsing command line arguments                
    configPropsFileName = None
       
    usage = 'Usage: uploadSegments [-c <config properties file>]'    
    try:
        opts, args = getopt.getopt(argv,"hc:",["config="])
    except getopt.GetoptError:
        print usage
        sys.exit(64)
    for opt, arg in opts:        
        if opt in ("-c", "--config"):
            configPropsFileName = getAbsolutePath(arg)
    
    updateJobRetries = False
    try:       
        # Initializing, loading configuration, etc.
        csLogger = CSLogger.setScript("uploadSegments")
        csLogger = CSLogger.getCSLogger("scripts.uploadSegments")        
        config = UBXConfig(configPropsFileName)
        authkey = config.getSegmentProducerAuthenticationKey()

        apimanager = UBXAPIManager(config)
        publishedDir = config.getSegmentPublishedFolder()
        deliveredDir = config.getSegmentDeliveredFolder()
        moveDeliveredSegment = config.getMoveSegmentToDeliveredFolder()
               
        # Get list of jobs waiting for data
        jobs = apimanager.getJobs(authkey, JobCategory.SEGMENT_EXPORT, config.getSegmentProducerEndpointID(), JobStatus.WAITING_TO_RECIEVE_DATA)
        if (len(jobs) == 0):
            csLogger.info("No jobs waiting to receive data")
        else:
            # load job retry status
            jobRetries = {}
            jobretryFilepath = getAppDataDir() + os.sep + "jobretries.txt"
            if os.path.exists(jobretryFilepath):
                try:  
                    f =  open(jobretryFilepath, 'rU')              
                    csvReader = csv.reader(f, delimiter=',')                
                    for row in csvReader:
                        retry = JobRetryStatus()
                        retry.jobId = row[0]
                        retry.retryExpirationTimestamp = row[1]
                        jobRetries[str(retry.jobId)] = retry               
                finally:
                    f.close()
                        
            for job in jobs:  
                if (job.subStatus != JobStatus.WAITING_TO_RECIEVE_DATA):
                    csLogger.info("Skipping jobID " + str(job.jobId) + " with substatus=" + job.subStatus)
                    continue
                
                now = int(round(time.time() * 1000))
                jobRetry = None 
                isRetry = False
                try:
                    jobRetry = jobRetries[str(job.jobId)]
                except KeyError:
                    csLogger.debug("Not a retry")
                
                if (jobRetry is not None):                    
                    if (now > int(jobRetry.retryExpirationTimestamp)):
                        # TBD: mark job as failed on UBX when API is available and remove this job from the file
                        csLogger.debug("JobId " + str(job.jobId) + " retry period expired. Skipping.")
                        continue
                    else:
                        updateJobRetries = True
                        isRetry = True
                
                segment = apimanager.getSegmentDetail(authkey, str(job.producerSegmentID))
                if (segment is not None):
                    segmentName = segment.name       
                    segmentFilename = "UBXSegment_" + segmentName + ".csv"              
                    segmentDataFile = publishedDir + os.sep + segmentFilename
                   
                    # Data file not found
                    if (not os.path.exists(segmentDataFile)):
                        csLogger.info("Error data file not found: " + segmentDataFile)
                        csLogger.info("Will retry in the next cycle.")
                        if (not isRetry):
                            retry = JobRetryStatus()
                            retry.jobId = job.jobId
                            retry.retryExpirationTimestamp = now + 60000*config.getJobWaitingForDataTimeout()
                            jobRetries[retry.jobId] = retry       
                            updateJobRetries = True            
                            csLogger.info("Add to retry jobs: jobId=" + str(job.jobId))
                        continue
                    
                    # Upload data
                    csLogger.info("Uploading data file: " + segmentDataFile)
                    if (apimanager.postSegmentData(job.jobId, segmentDataFile)):                        
                        # move segment csv file and delete segment in ubx
                        if (moveDeliveredSegment):
                            destfile = deliveredDir + os.sep + segmentFilename
                            try:
                                if (os.path.exists(destfile)):
                                    os.remove(destfile)
                                os.rename(segmentDataFile, destfile)
                                apimanager.deleteSegment(job.producerSegmentID)
                            except OSError:
                                csLogger.error("Error moving file from " + segmentDataFile + " to " + destfile)                                   
                else:
                    csLogger.info("Segment id " + str(job.producerSegmentID) + " no longer published for jobId " + str(job.jobId))
                    
    except Exception, e:
        csLogger.error('Upload Audiences script terminating with error!')
        csLogger.error(e.getMessage(),e)                                         
                                 
    finally:
        if (updateJobRetries):
            try:  
                jobretryFilepath = getAppDataDir() + os.sep + "jobretries.txt"
                f =  open(jobretryFilepath, 'wb')              
                csvWriter = csv.writer(f, delimiter=',')    
                for retry in jobRetries.values():
                    cols = []
                    cols.append(retry.jobId)
                    cols.append(retry.retryExpirationTimestamp)
                    csvWriter.writerow(cols)
     
            finally:
                f.close()
        
        csLogger.info('Upload Audiences script completed.')  

class JobRetryStatus:
    def __init__(self):        
        self.jobId = None
        self.retryExpirationTimestamp = None
        self.retryStatus = None
        
    
    

if __name__ == '__main__':    
    UploadSegments(sys.argv[1:])
