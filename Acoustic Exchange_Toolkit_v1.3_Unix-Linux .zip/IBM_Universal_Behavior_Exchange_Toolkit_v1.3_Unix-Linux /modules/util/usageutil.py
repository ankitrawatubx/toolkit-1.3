##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################


def referToCommandLineHelp():
    print 'Please run the script with -h or --help for more information on command line options.'
    
def reportSpaceInOptionValue(csLogger, args):
    msg1= 'The following option value is not correct: \''+ str(args)+ '\'. Please make sure there are no spaces in option values (such as file paths), or that the values are surrounded by double quotes.'
    msg2= 'If you are trying to pass \''+ str(args) + '\' as a part of a list of values, make sure that there are no spaces in or between list elements, or that the entire list is surrounded by double quotes.'
    #print 'ERROR: '+ msg1 
    #print msg2
    csLogger.error(msg1)
    csLogger.info(msg2)
    referToCommandLineHelp()
