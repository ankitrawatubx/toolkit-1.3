import sys
del sys.modules[__name__]
1 / 0
