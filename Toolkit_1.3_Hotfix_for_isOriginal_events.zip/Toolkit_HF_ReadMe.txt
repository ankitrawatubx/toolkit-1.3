https://acoustic-jiraconf.atlassian.net/browse/EXC-752
Here is the summary of fix on 1.3 on multiple values for same identifier. 

Deployment :

a) Deploy UBX Toolkit 1.3 and configure events endpoint
b) Look for following property in example_config.properties and paste it in 1.3 environment. 
# (Default=,) Separator for joining values for multiple identifiers having same name. 
# Default value is a comma. This separator will be used for appending value in generated TSV file
# for identifiers having same name. 
ubx.toolkit.separator=,
After step (b) you should have existing 1.3 with above property added. 

c) Backup lib\campubx.jar into some other folder. Do not keep it renamed in same folder. Put campubx.jar from zip into \lib folder.
d) Backup eventsdownload.py and ubxconfig.py and put ones from zip. 


Toolkit behavior after fix:

a) After applying fix, run eventsDownload.bat to download an event that has same identifier with multiple values. 
b) It should download the json and also create TSV with following details:
i) for every identifier, it'll add _original column. 
ii) The _original column in TSV will have original value
iii) The regular column in TSV will have all values separated by config property separator value
c) For identifiers you need original values for, update mapping and SQL. 
d) Ensure you update DB table for events you are updating mapping file for. 
e) Execute eventsImport.bat

After a specific mapping updating, your mapping section would look like :
 
<Column>
   <Name>Email</Name>
   <EventField>identifier_email</EventField>
</Column>
<Column>
   <Name>Email_Original</Name>
   <EventField>identifier_email_original</EventField>
</Column>
 

After a specific column update, your DB, for example, would look like :

Customer_ID					Customer_ID_ORIGINAL
CHEN12|CHENTH12|CHENTH12_CHANGED		CHEN12

You should not need to update / change any mapping or DB unless you need original value in DB in a specific column of it's own, ensuring backward compatibility in events import. 
