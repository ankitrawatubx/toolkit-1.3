##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015, 2016.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import os
import sys
import getopt
import traceback
import codecs

from conf.cfg import Config, getAbsolutePath, getAppDataDir
from conf.ubxconfig import UBXConfig
from ubx.apimanager import UBXAPIManager
from java.lang import Exception
from java.lang import Throwable
from java.text import SimpleDateFormat

from com.ibm.emm.integration.log import CSLogger, CSLogStats
from com.ibm.emm.integration.util import NormalizeUtils
from com.ibm.emm.integration.ubx import EventDataReader, EventDataWriter

def EventsDownload(argv):    

    # Parsing command line arguments                
    configPropsFileName = None
    format = "tsv"
    downloadFileCount = 0
       
    usage = 'Usage: eventsDownload [-c <config properties file>]'    
    try:
        opts, args = getopt.getopt(argv,"hc:",["config="])
    except getopt.GetoptError:
        print usage
        sys.exit(64)
    for opt, arg in opts:        
        if opt in ("-c", "--config"):
            configPropsFileName = getAbsolutePath(arg)
        elif opt in ("-h"):
            print usage
            sys.exit(0)        
    
    try:       
        # Initializing, loading configuration, etc.
        csLogger = CSLogger.setScript("eventsDownload")
        csLogger = CSLogger.getCSLogger("scripts.eventsDownload")        
        config = UBXConfig(configPropsFileName)
        downloadDir = config.getLocalDownloadDir() + "/"
        if not os.path.exists(downloadDir):
            os.makedirs(downloadDir) 
                
        getMoreFiles = True
        
        csLogger.info("***** Download Events script started. *****")  
        
        while (getMoreFiles):
            # Calling the UBX API to download the events        
            apimanager = UBXAPIManager(config)
            
            try:
                eventFiles = apimanager.getEventFileList()
            except Exception, e:
                csLogger.error('Error calling event files API ',e) 
                sys.exit(64)        
            
            if (eventFiles is not None):
                
                if (len(eventFiles) == 0):
                    getMoreFiles = False
                    
                encoding = config.getEncoding()
                if (encoding is not None):
                    csLogger.info("Encoding specified in config file is: " + encoding)
                    if (len(encoding) == 0):
                        encoding = None
                
                for eventFile in eventFiles:
                                        
                    shouldDeleteFileFromServer = config.isDeleteFilesFromServer()  
                    csLogger.info("shouldDeleteFileFromServer is: " + str(shouldDeleteFileFromServer))                 
                    
                    filename = NormalizeUtils.toValidFileName(eventFile.getId())            
                    eventFilePath = downloadDir + filename + ".json"
                    
                    # get the events file
                    content = apimanager.getEventFile(eventFile.getId())
                    downloadFileCount = downloadFileCount + 1

                    try:                                
                        ucontent = content
                        # always save events as json file
                        eventFilePath = downloadDir + filename + ".json"
                        csLogger.info('Saving events to: ' + eventFilePath)
                        if (encoding is not None):                 
                            pencoding = encoding.lower()
                            csLogger.info("JSON file encoding is: " + pencoding)   
                            
                            ucontent = unicode(content, pencoding)
                            f = codecs.open(eventFilePath, "wb", encoding=pencoding)                            
                        else:
                            f = open(eventFilePath, "wb")
                             
                        f.write(ucontent)
                        f.close()
        
                        if (not os.path.exists(eventFilePath)):
                            csLogger.error("Error saving events to file: " + eventFilePath)
                            shouldDeleteFileFromServer = False
                            getMoreFiles = False
                        
                            
                        if (format == "tsv"):
                            # translate json file to tsv
                            tsvFilePath = downloadDir + filename + ".tsv"
                            csLogger.info('Saving events to: ' + tsvFilePath)
                            
                            eventDataReader = EventDataReader()
                            if (encoding is not None):
                                eventDataReader.setEncoding(encoding)
                                
                            eventDataList = eventDataReader.readEventsFromString(ucontent)
                            eventDataWriter = EventDataWriter()
                            if (encoding is not None):
                                eventDataWriter.setEncoding(encoding)
                            eventDataWriter.writeTSVFile(eventDataList, tsvFilePath)
        
                            if (not os.path.exists(tsvFilePath)):
                                csLogger.error("Error saving events to file: " + tsvFilePath)
                                shouldDeleteFileFromServer = False
                                getMoreFiles = False
                            
                        # Delete the file from server
                        if (shouldDeleteFileFromServer):
                            try:
                                csLogger.info('Deleting file on server: ' + eventFile.getId())
                                apimanager.deleteEventFile(eventFile.getId())
                            except:
                                getMoreFiles = False
    
                        else:
                            getMoreFiles = False

                    except IOError, ioe:
                        csLogger.error('Exception caught writing file: ' + filename)                              
                        csLogger.error(str(ioe))
                    except UnicodeEncodeError, ue:
                        csLogger.error('Unicode Encode error: ' + filename)                              
                        csLogger.error(str(ue))
                    except LookupError, lue:
                        csLogger.error('Lookup error: ' + filename)                              
                        csLogger.error(str(lue))        
                        raise lue                    
                    except Exception, je:
                        csLogger.error('Exception downloading file: ' + filename)                              
                        csLogger.error(str(je.getMessage()))                        
            else:
                getMoreFiles = False
        
    except Exception, e:
        csLogger.error('EventsDownload script terminating with error!', e)
        
    finally:
        csLogger.println()
        csLogger.info('EventsDownload Script Run Summary')
        csLogger.info('Event files downloaded: ' + str(downloadFileCount))
        CSLogStats.printSummary(csLogger)
        csLogger.info("***** Download Events script completed. *****") 

if __name__ == '__main__':    
    EventsDownload(sys.argv[1:])
