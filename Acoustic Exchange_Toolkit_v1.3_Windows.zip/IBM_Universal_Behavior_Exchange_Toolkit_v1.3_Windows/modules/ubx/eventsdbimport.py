##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015, 2016.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import os
import sys
import getopt
import traceback

from conf.cfg import Config, getAbsolutePath
from conf.ubxconfig import UBXConfig
from util.usageutil import referToCommandLineHelp, reportSpaceInOptionValue

from java.lang import Throwable
from com.ibm.emm.integration.log import CSLogger, CSLogStats
from com.ibm.emm.integration.ubx import EventsDBImporter
from com.ibm.emm.integration.ddi import DBInsertProperties

def EventsDBImport(argv):    
    csLogger = CSLogger.setScript("eventsDBImport")
    csLogger = CSLogger.getCSLogger("scripts.eventsDBImport")        
    csLogger.info("Running eventsDBImport...")

    # Parsing command line arguments                
    configPropsFileName = None
    jdbcPropsFileName= None
    sourceFilePath = None
    sourceDir = None
    dbMappingFilePath = None
    
    usage = 'Usage: eventsDBImport [-c <config properties file> -j <jdbc properties file> -i <input file> -f <input folder> -m <db mapping file>]'    
    try:
        opts, args = getopt.getopt(argv,"hc:j:i:m:f:",["config=","jdbc=","inputfile=","mapping=","inputdir="])
    except getopt.GetoptError:
        print usage
        sys.exit(64)
    if ( (args is not None) and (len(args)> 0) ):
        reportSpaceInOptionValue(csLogger, args[0])        
        sys.exit(0)            
    for opt, arg in opts:        
        if opt in ("-c", "--config"):
            configPropsFileName = getAbsolutePath(arg)
        elif opt in ("-j", "--jdbc"):
            jdbcPropsFileName = getAbsolutePath(arg)
        elif opt in ("-i", "--inputFile"):
            sourceFilePath = getAbsolutePath(arg)
        elif opt in ("-m", "--mapping"):
            dbMappingFilePath = getAbsolutePath(arg)
        elif opt in ("-f", "--inputdir"):
            sourceDir = getAbsolutePath(arg)
        elif opt in("-h"):
            print usage
            sys.exit(0)

    if (dbMappingFilePath is None):
        csLogger.error('You must specify a database mapping file')        
        print usage
        sys.exit(64)        
    else:
        if(not os.path.exists(dbMappingFilePath)):
            csLogger.error('Specified mapping file (-m option), ' + dbMappingFilePath +  ', does not exist')
            sys.exit(64) 
    
    if (sourceFilePath is None):
        if (sourceDir is None):
            csLogger.error('You must specify a TSV file as the input file or specify an input folder')        
            print usage
            sys.exit(64)
        else:
            if(not os.path.exists(sourceDir)):
                csLogger.error('Specified input folder (-f option), ' + sourceDir +  ', does not exist')
                sys.exit(64)             
    else:
        if(not os.path.exists(sourceFilePath)):
            csLogger.error('Specified TSV file (-i option), ' + sourceFilePath +  ', does not exist')
            sys.exit(64) 
    
    try:       
        config = UBXConfig(configPropsFileName)
        
        # Initializing, loading configuration, etc.
        DBInsertProperties.getProperties().load(configPropsFileName, jdbcPropsFileName)

        eventsImporter = EventsDBImporter()
        eventsImporter.setEventDBMappingFilepath(dbMappingFilePath)
        
        encoding = config.getEncoding()
        if (encoding is not None):
            csLogger.info("Encoding specified in config file is: " + encoding)
            if (len(encoding) > 0):
                eventsImporter.setEncoding(encoding)
            
        if (sourceFilePath is not None):    
            csLogger.info("Processing: " + sourceFilePath)            
            eventsImporter.processTSVFile(sourceFilePath)
        else:
            tsvfiles = os.listdir(sourceDir)
            csLogger.info("Processing folder: " + sourceDir)        
            count = 0    
            
            for tsvfile in tsvfiles:
                tsvfilepath = sourceDir + os.sep + tsvfile
                if os.path.isfile(tsvfilepath) and tsvfile.endswith(".tsv"):      
                    csLogger.info("Processing: " + tsvfilepath)              
                    eventsImporter.processTSVFile(tsvfilepath)
                    count = count + 1
                    
            if (count == 0):
                csLogger.info("No tsv files to import.")
            
            csLogger.info("Number of tsv files processed: " + str(count))
    
    except Throwable, e:
        csLogger.error('Error importing events', e)   
    
    finally:
        csLogger.println()
        csLogger.info('Script Run Summary')
        CSLogStats.printSummary(csLogger)
   
if __name__ == '__main__':    
    EventsDBImport(sys.argv[1:])
