##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
def openTag(tagName):
    return "<" + tagName + ">"

def closeTag(tagName):
    return "</" + tagName + ">"

def writeTag(tagName, value):
    return openTag(tagName) + str(value) + closeTag(tagName) + "\n"
