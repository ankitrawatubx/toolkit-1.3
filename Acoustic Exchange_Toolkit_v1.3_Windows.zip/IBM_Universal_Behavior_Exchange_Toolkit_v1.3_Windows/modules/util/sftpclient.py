##################################################################################
#   Licensed Materials - Property of IBM
#   IBM Universal Behavioral Exchange Toolkit Materials
#   Source code for IBM Universal Behavioral Exchange Toolkit
#   (c) Copyright IBM Corporation 2015.
#   US Government Users Restricted Rights - Use, duplication or disclosure
#   restricted by GSA ADP Schedule Contract with IBM Corp.
##################################################################################
import time;
from jarray import zeros;
import java.lang;
import com.jcraft.jsch;

from com.jcraft.jsch import JSchException, SftpException
from com.ibm.emm.integration.log import CSLogger

class SFTPClient(object):
    csLogger = CSLogger.getCSLogger("scripts.util.SFTPClient")
    
    def __init__(self, config):
        self.ftpHost = config.getLRFTPHost();
        self.ftpPort = config.getLRFTPPort();
        self.ftpUser = config.getLRUserName();
        self.ftpPW = config.getLRPassword();
        self.onErrorOverallRetryTimeMillis= config.getOnErrorOverallRetryTime() 
        self.onErrorRetryNum= config.getOnErrorRetryNum();
        self.jsch = None;
        self.session = None;
        self.channel = None;
        self.sftpChannel = None;
        
    def getHost(self):
        return self.ftpHost
    
    def getPort(self):
        return self.ftpPort
    
    def setupConnection(self):
        self.__setupConnection(False)
        self.csLogger.info("Connected to " + self.ftpHost + ":" +  str(self.ftpPort))
        
    def setupSessionAndChannelConnection(self):
        self.__setupConnection(True)

    def __setupConnection(self, setupChannelConnection):   
        sleepIntervalMillis= 1000
        startMillis= int(round(time.time()*1000))               
        
        # Retry loop...
        while(True):               
            try:
                self.jsch = com.jcraft.jsch.JSch();

                self.session = self.jsch.getSession(java.lang.String(self.ftpUser), java.lang.String(self.ftpHost),
                                                    java.lang.Integer(self.ftpPort));
                self.session.setConfig(java.lang.String("StrictHostKeyChecking"), java.lang.String("no"));
                self.session.setPassword(java.lang.String(self.ftpPW));
                self.session.connect();
                if setupChannelConnection:
                    self.channel = self.session.openChannel(java.lang.String("sftp"));
                    self.channel.connect();                
                return self.jsch;                    
            
            except JSchException, jsche:                   
                retry= (int(round(time.time()*1000))- startMillis )< self.onErrorOverallRetryTimeMillis
                if(retry):                    
                    self.csLogger.warn('Failed to connect to '+ self.ftpHost+ ' over SFTP: '+ str(jsche).replace('Auth ', 'Authentication '))                   
                    self.tryCleanup()
                    sleepIntervalMillis*= 2
                    self.csLogger.info('Waiting '+ str(sleepIntervalMillis//1000)+ ' second(s) and retrying...')                    
                    time.sleep( sleepIntervalMillis/1000.0 )                                                           
                else:                         
                    if 'Auth fail' in str(jsche):                               
                        raise java.lang.Exception('Failed to authenticate with '+ self.ftpHost+ '. Confirm that the server connections and login credentials are correctly configured for the integration user.', jsche)
                    else:
                        raise java.lang.Exception('Failed to connect to '+ self.ftpHost+ ' over SFTP', jsche)       
        
    
    def tryCleanup(self):
        if (self.jsch == None):
            return;

        if (self.session == None):
            return;
        try:
            if(self.session.isConnected()):
                self.session.disconnect();            
        except java.lang.Exception, e:
            return e;
        

    def upload(self, localFilePath, remoteFilePath):
        self.channel = self.session.openChannel(java.lang.String("sftp"));
        self.channel.connect();
        self.channel.put(java.lang.String(localFilePath), java.lang.String(remoteFilePath));
        self.channel.exit();
        
           


    #=============================================================================
    # A number of convenience methods.
    # Exceptions handling is supposed to be done by the calling code,
    # as there might be some retry logic.   
    #=============================================================================
      
    def download(self, src, dst):        
        self.channel.get(src, dst);
        
   
    def cd(self, directory):
        self.channel.cd(directory);
   
        
    def ls(self, pattern):   
        return self.channel.ls(pattern);
   
    
    def rename(self, currName, newName):
        self.channel.rename(currName, newName);
        
    def pwd(self):
        return self.channel.pwd();
    
    def rm(self, fileName):
        self.channel.rm(fileName);
